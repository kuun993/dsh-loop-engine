/**
 * Per-engine styling for the chat turn-status line (the "深度求索中..." row).
 *
 * That row is rendered from inside the harness's ChatView and its words belong
 * to ui-chat: the row is not a slot, and ui-chat owns the `chat` locale
 * namespace (a second `locale.register` for the same namespace throws), so a
 * plugin cannot change the text. What it CAN do is restyle the element, and
 * that is all this module does — it paints an engine-specific glyph and color
 * onto the row while the session on screen runs a hosted engine, and leaves the
 * stock look alone otherwise.
 *
 * WHICH engine it paints is the SESSION ON SCREEN's, not the settings default.
 * {@link reflectTurnStatusEngine} is driven from the per-session engine cache
 * (`./session-engine.ts`) — the same authoritative answer the header chip and
 * the composer render from, the plugin's own Remote read off the session's
 * durable log — and it is driven by the ONE hook those two surfaces share
 * (`./use-session-engine.ts`). So this row cannot disagree with the two surfaces
 * beside it; while it was keyed off the settings store it did, and painted
 * Claude Code's glyph onto every session's row whenever claude-code was the
 * default, a session running pi included.
 *
 * The reflection's SUBJECT is still a document-level attribute rather than the
 * row's own element: the sheet has to reach a class the harness hashes (see
 * {@link ROW_SELECTORS}), which takes an attribute selector on an ancestor,
 * and the row offers no session-scoped hook for a plugin to hang it on. A
 * document-level attribute has exactly ONE owner at a time, though — and on this
 * page the WRITERS outnumber the reader: the chip and the composer of every
 * session that has been rendered carry an answer, the session the user has just
 * left included, and the cache publishes a session's answer regardless of what is
 * on screen. So "whoever reflected last" is not "the session on screen", and an
 * implementation that read it as one shipped the bug this guard ends: a
 * background session's answer — or the late answer of the session the user just
 * left — painted ITS engine onto the row of the session on screen, and a session
 * running pi showed Kimi's moon.
 *
 * The owner is therefore DECLARED, not inferred: a reflection names the session
 * it speaks for and writes only while that session is the row's focus
 * ({@link focusTurnStatusSession}); a reflection whose subject is not the focused
 * session is a NO-OP, so only the session on screen can paint and only it can
 * un-paint. The chip and the composer of one session reflect the same value (the
 * write is idempotent); the focus is withdrawn by
 * {@link blurTurnStatusSession}, which acts only while the focus is still the
 * departing session's (React runs a departing component's cleanup in no
 * guaranteed order against an arriving one's, so an unconditional withdrawal
 * would un-focus the session that just took over); and the attribute itself is
 * never withdrawn on unmount: the sibling surface of the same session still
 * paints by it, and a leftover attribute is inert on a page whose turn-status row
 * is not rendered.
 *
 * The paint is gated TWICE, and both gates are needed on the 0.1.7 line.
 *
 * First, on the session being MID-TURN, through a second document-level
 * attribute ({@link RUNNING_ATTR}, written from the same reflection). On the
 * 0.1.5 line the row only exists while a turn is in flight, so the engine
 * attribute alone was enough; on the 0.1.7 line that same button stays on screen
 * after the turn ends, as the collapsed summary that reads "用时 4秒" — an
 * engine-only gate leaves the glyph and the sweep animating on a finished turn,
 * which is not what the live line means. The gate is a surface's own answer
 * (`session.running`, which every session-scoped seat receives), so a surface
 * that cannot answer passes nothing and leaves it alone rather than guessing.
 *
 * Second, and this is the one a session-level gate cannot express: on the
 * 0.1.7 line EVERY turn's row stays on screen, so while turn N runs, turns
 * 1..N-1 are still there. A session-wide gate turns the whole sheet on for all
 * of them — the finished rows would wear the glyph again for as long as any
 * later turn ran. The row selector therefore carries `:disabled` (see
 * {@link ROW_SELECTORS}), which is how ui-chat marks the live row. The two
 * gates answer different questions — "is a turn in flight for this session" and
 * "is this row the one it belongs to" — and neither alone is enough.
 *
 * Three facts about the harness markup make that safe and specific:
 *   - the row has one stable handle per harness generation — an
 *     `[hash]_turnStatus` class suffix on the 0.1.5 line, and, on the 0.1.7
 *     line, the `data-turn-process` button whose text is a `<span>` whose hashed
 *     class ends `_label` — so each generation gets its own copy of the sheet
 *     ({@link ROW_SELECTORS}) and the one the running app renders matches while
 *     the other stays inert;
 *   - its gradient paints through the `--dsw-static-deepseek-*` custom
 *     properties, so recoloring is a variable override rather than a fight
 *     over `background` and `background-clip`;
 *   - the glyph rides a `::before` pseudo-element, so the row's real text node
 *     — and the status it announces — is untouched.
 *
 * This sheet deliberately keeps the row animating even when the OS reports
 * `prefers-reduced-motion: reduce` (see the re-asserted sweep below): the
 * deployment's Windows images ship with client-area animation off, which
 * otherwise freezes every indicator here — the sweep and the glyph alike.
 * In-process sessions keep the stock reduced-motion behaviour.
 *
 * @module dsh-loop-engine/client/turn-status
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { LoopEngineId } from '../agent-preset-ids.ts';
/**
 * Reflect the engine of the session ON SCREEN; `undefined` restores the stock
 * row.
 *
 * The caller names the session it speaks for, and that is the row's SUBJECT: a
 * reflection paints its session's engine only while that session is the focused
 * one ({@link focusTurnStatusSession}), and is a NO-OP otherwise — the whole
 * guard, and the reason the attribute can no longer be taken over by a session
 * the user is not looking at. The subject is an explicit argument rather than
 * ambient state, so a caller cannot reflect without saying whose engine it is,
 * and cannot say "whoever, I don't know".
 *
 * `in-process` is the harness's own row, and `undefined` is every answer that
 * names no engine at all: a session the host reports as `legacy` (it ran a
 * hosted engine, the id never said which) or `unset`, a session whose first
 * answer has not landed yet, and an answer dropped in preparation for a re-read.
 * None of them paints — naming an engine for an unknown one is the misreport
 * this module was fixed for — so each clears the attribute. The clear is as
 * authoritative as the paint: a session that takes the focus with no answer yet
 * takes the previous session's paint off with it.
 *
 * The write is idempotent and never a withdrawal: the chip and the composer of
 * one session both come through here with the same value, and unmounting never
 * clears the attribute, because the sibling surface of the same session is still
 * on screen painting through it.
 *
 * The MID-TURN gate is written from here as well, but only by a surface that can
 * answer it (`running` given): the sheet is gated on both, because the 0.1.7 row
 * outlives its turn, and a surface with no answer must leave the gate as the
 * surface that has one left it rather than guess.
 *
 * The NO-OP covers the late reflection as well — the one from the session the
 * user has just left, whose own answer landing after the switch used to paint
 * over the session that replaced it.
 * @param sessionId - the session this reflection speaks for, or undefined for a
 *   page with no session at all (the new-session page, which has no turn-status
 *   row): such a page has nothing to say about the row, so nothing is written and
 *   nothing is withdrawn — it leaves the row it found alone.
 * @param engine - the engine that session runs, when it is known.
 * @param running - whether that session is mid-turn, when the surface knows;
 *   omitted by a surface with no answer, which leaves the gate alone.
 */
export declare function reflectTurnStatusEngine(sessionId: string | undefined, engine: LoopEngineId | undefined, running?: boolean): void;
/**
 * Declare which session's surfaces are on screen — the row's one subject.
 *
 * Only the focused session may paint ({@link reflectTurnStatusEngine}), which is
 * what keeps the row on the session the user is looking at: the alternative,
 * "whoever writes last owns the row", was the bug this guard ends, because the
 * chip and the composer of EVERY session that has been rendered write here, and
 * a session's answer can land after the user has left it.
 *
 * The caller is the component that renders that session: only a component knows
 * which session is the one on screen, and the hook both of that session's
 * surfaces share (`./use-session-engine.ts`) is the only place that declares it.
 * @param sessionId - the session whose surfaces are now on screen.
 */
export declare function focusTurnStatusSession(sessionId: string): void;
/**
 * Withdraw the focus — but only while it is still this session's.
 *
 * The guard is the point: React offers no ordering guarantee between a departing
 * component's cleanup and an arriving one's, so an unconditional withdrawal would
 * let the session the user has just left un-focus the session that replaced it
 * and silence the row. A session that is no longer the focus has nothing to
 * withdraw; unmounting also never clears the attribute itself, which the sibling
 * surface of the same session (and, for a session that is still on screen, the
 * next focus) still paints by.
 * @param sessionId - the session whose surface is going away.
 */
export declare function blurTurnStatusSession(sessionId: string): void;
/**
 * Install the per-engine turn-status stylesheet for the lifetime of `ctx`.
 *
 * This is the sheet and nothing else: which engine it selects is written by
 * {@link reflectTurnStatusEngine}, driven from the session on screen's own
 * authoritative answer (`./session-engine.ts`), through the hook the chip and
 * the composer share (`./use-session-engine.ts`) — not from the settings
 * default.
 * @param ctx - the client root context.
 */
export declare function installTurnStatusStyles(ctx: ClientContext): void;
//# sourceMappingURL=turn-status.d.ts.map
/**
 * Loop engine settings page copy (Chinese product copy; comments in English).
 * @module dsh-loop-engine/client/locales
 */
import { type LoopEngineId, type LoopEngineRefusalCode, type SessionEngine } from '../agent-preset-ids.ts';
/** Copy keys of the loop engine settings page. */
export interface LoopEngineKey {
    /** Settings navigation label. */
    nav: string;
    /** Panel description under the title. */
    description: string;
    /** Option label: the default in-process loop driver. */
    engineInProcess: string;
    /** Option label: the Claude Code CLI driver. */
    engineClaudeCode: string;
    /** Option label: the Codex CLI driver. */
    engineCodex: string;
    /** Option label: the Pi CLI driver. */
    enginePi: string;
    /** Option label: the Kimi Code CLI driver. */
    engineKimi: string;
    /** Option label: a session on the pre-routing single preset id. */
    engineLegacy: string;
    /** Option label: a session this plugin holds no engine record for. */
    engineUnrecorded: string;
    /** Composer picker label while the session's own engine has no answer yet. */
    engineLoading: string;
    /** Settings toggle: show the engine picker in the chat page composer. */
    showInComposerLabel: string;
    /** Unavailable-state message. */
    unavailable: string;
    /** Notice shown when the selection would interrupt running agents. */
    switchNotice: string;
    /** Saving state label. */
    saving: string;
    /** Settings-section confirmation title: the picker that changes the new-session default. */
    confirmTitle: string;
    /** Settings-section confirmation body: the picker that changes the new-session default. */
    confirmBody: string;
    /** Session-header chip tooltip: the engine this session runs, and what decides it. */
    sessionNotice: string;
    /** Session-header chip tooltip when the session's engine was never recorded. */
    legacySessionNotice: string;
    /** Marker lead-in naming the engine a session's record holds while another one drives it. */
    enginePendingPrefix: string;
    /** Marker trailer saying that recorded engine is not what the session runs. */
    enginePendingSuffix: string;
    /** Composer menu-row suffix marking the engine a session's record holds but is not running. */
    engineMenuPendingSuffix: string;
    /** Session-header chip tooltip while the record names an engine the session is not running. */
    pendingSessionNotice: string;
    /** Composer picker tooltip while the record names an engine the session is not running. */
    pendingComposerHint: string;
    /** Composer picker tooltip: it chooses this session's engine, and which picks apply immediately. */
    composerHint: string;
    /** Title of the notice reporting a refused per-session switch. */
    switchFailedTitle: string;
    /** Body of a refused per-session switch: the session is not open yet. */
    refusedSessionClosed: string;
    /** Body of a refused per-session switch: a turn is in flight and is not interrupted. */
    refusedTurnRunning: string;
    /** Body of a refused per-session switch: a delegated child's engine follows its parent. */
    refusedSubagentSession: string;
    /** Body of a refused per-session switch while this process has no loop engine router. */
    refusedRouterNotReady: string;
    /** Body of a refused per-session switch whose engine record could not be written. */
    refusedRecordFailed: string;
    /** Body of a refused per-session switch whose successor engine could not be built. */
    refusedRebuildFailed: string;
    /** Title of the confirmation shown before a switch that reloads the page. */
    switchReloadConfirmTitle: string;
    /** Body of that confirmation: what the reload is for, and what this page loses with it. */
    switchReloadConfirmBody: string;
    /** Confirm action label of that confirmation. */
    switchReloadConfirmAction: string;
    /** Title of the notice shown while a per-session switch reloads the page. */
    switchReloadTitle: string;
    /** Body of that notice: what the reload is doing, and that it returns to this session. */
    switchReloadBody: string;
    /** Message when this page cannot reach the engine switch endpoint at all. */
    switchUnavailable: string;
    /** Confirmation action label of the settings section's own dialog. */
    confirmAction: string;
    /** Cancel action label of the settings section's own dialog. */
    cancelAction: string;
    /** Accessible close-button label of the settings confirmation and the switch notices. */
    closeLabel: string;
    /** Notice shown while a hosted engine drives the session: the model seat is the engine's own business. */
    hostedEngineModelNotice: string;
}
/** Simplified Chinese copy. */
export declare const zh: Record<keyof LoopEngineKey, string>;
/** English copy. */
export declare const en: Record<keyof LoopEngineKey, string>;
/**
 * The copy key naming one engine, shared by the session header chip and the
 * composer picker (both name a resolved engine, and neither may invent a name
 * for one of the two non-engine session states).
 * @param engine - a resolved engine id.
 * @returns the key of that engine's own label.
 */
export declare function engineLabelKey(engine: LoopEngineId): keyof LoopEngineKey;
/**
 * The copy key naming the engine a session RUNS, for the two surfaces that name
 * one (the header chip and the composer picker's trigger).
 *
 * The three-state is folded in one place so the two surfaces cannot answer the
 * "which engine is this?" question differently — and so neither can hand it the
 * pending engine: {@link SessionEngine} is the ACTUAL answer by construction, and
 * the recorded-but-not-adopted engine travels beside it
 * (`SessionEngineReport.pending`), where {@link pendingEngineText} turns it into
 * a marker rather than a name.
 * @param state - what the session's engine read answered for its live engine.
 * @returns the key of that state's label.
 */
export declare function engineStateLabelKey(state: SessionEngine): keyof LoopEngineKey;
/**
 * The marker naming the engine a session's record holds while something else is
 * driving it.
 *
 * It is an aside, never a name: a surface appends it to the engine the session is
 * actually running, so the user reads "Pi CLI, and the record says X" — not "X".
 * Both surfaces that show a session's engine render it, which is why it is
 * composed here rather than in either of them.
 *
 * Its trailer deliberately makes no promise about WHEN the recorded engine takes
 * over (`enginePendingSuffix`): a switch that has to release the session's agent
 * lands through a page reload, and this marker never survives one — it is what
 * the user sees when that release did not take, and picking the engine again is
 * the action that retries it.
 * @param t - the surface's copy function.
 * @param engine - the engine the session's own record names.
 * @returns the complete marker, e.g. `切到 Pi CLI · 尚未接管`.
 */
export declare function pendingEngineText(t: (key: keyof LoopEngineKey) => string, engine: LoopEngineId): string;
/**
 * How one refused switch reads: which local copy says it, and whether the host's
 * own sentence belongs under that copy as detail.
 *
 * The refusal arrives from the host as a code plus the host's English sentence
 * about one session (`LoopEngineRefusal.reason`), and the sentence is what a
 * surface used to show verbatim — which is how a user got a raw
 * `session "…" is running; switch its engine after this turn ends` for a state
 * this plugin can say perfectly well in the user's own language. So the code
 * decides the message here, and the sentence is kept where it is genuinely
 * additional information: the two failures whose copy is generic and whose text
 * carries the underlying cause (a write error, a driver that would not start).
 */
export interface RefusalFace {
    /**
     * Body copy key for this refusal. Absent when no local copy can say it — an
     * absent or unknown code, where the host's own sentence IS the message
     * (`undefined` is also what a client older than the host normalizes an
     * unrecognized code to, `src/client/session-engine.ts` `parseSelectResult`).
     */
    readonly body?: keyof LoopEngineKey;
    /** Whether the host's `reason` is rendered under the body as detail. */
    readonly detail: boolean;
}
/**
 * Resolve what one refused switch shows.
 *
 * A refusal ALWAYS leaves something readable: a known code gets this plugin's own
 * copy (and, for the two technical failures, the host's sentence under it), while
 * an absent or unknown code falls back to that sentence as the message itself.
 * @param code - the code the host's refusal carried, or undefined when it carried
 * none this build knows.
 * @returns the copy key to render, plus whether the host's own text is shown as
 * detail.
 */
export declare function refusalFace(code: LoopEngineRefusalCode | undefined): RefusalFace;
//# sourceMappingURL=locales.d.ts.map
/**
 * Loop engine settings plugin, browser half. Registers the "Loop engine" page
 * under the settings section slot and binds one store to whichever settings
 * client the running harness serves: the 0.1.7 `configForms` form for the
 * plugin's own `loop-engine` profile entry, or the 0.1.5 `settingsScope` for its
 * `agent-loop-engine` settings section. Two inject callbacks register the page,
 * one per generation — whichever service exists fires, and the client bundle
 * never imports a host package, so it cannot probe the generation like the node
 * half does.
 * Export discipline: packages/client/AGENTS.md.
 * @module dsh-loop-engine/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type LoopEngineKey } from './locales.ts';
export type { LoopEngineSectionInjected, LoopEngineSectionProps } from './LoopEngineSection.tsx';
export type { LoopEngineBadgeInjected, LoopEngineBadgeProps } from './LoopEngineBadge.tsx';
export type { LoopEngineComposerSelectInjected, LoopEngineComposerSelectProps } from './LoopEngineComposerSelect.tsx';
export type { LoopEngineState } from './store.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Loop engine settings page copy. */
        'settings.loop-engine': LoopEngineKey;
    }
}
/**
 * Required services (cordis fiber inject). Only the services BOTH generations
 * provide are listed statically: `configForms` (0.1.7) and `settingsScope`
 * (0.1.5) are mutually exclusive, so each is injected inside its own callback
 * rather than named here. The target slot is declared by ui-settings' apply;
 * registration depends on it through `slots.inject()`.
 */
export declare const inject: string[];
/**
 * Register the Loop engine section once the `settings.section` declaration is
 * on the ledger and bind its store to whichever settings client is present.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map
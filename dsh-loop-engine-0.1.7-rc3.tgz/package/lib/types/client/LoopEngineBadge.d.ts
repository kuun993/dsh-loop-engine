/**
 * Session header engine chip: a read-only pill naming the engine THIS session
 * runs, read from this plugin's own Remote — which answers from the plugin's own
 * per-session record and, for a session with none, from the session's durable
 * log: the same read the router routes on, so the chip cannot disagree with what
 * the session is actually driven by.
 *
 * It deliberately does NOT read the client session list's `agentPreset`
 * projection: that value is a cache-shaped hint, and it names the preset the
 * session was CREATED with, which is the wrong answer both for a session that
 * switched while it was blank and for one that switched after it started. The
 * harness's own preset label reads that same hint and lags the same way; this
 * chip does not.
 *
 * The settings section's engine is NOT what this chip shows: that value is only
 * the default for sessions created later, and a session created before a default
 * change keeps running the engine it has. The two sessions that name no engine
 * are reported as themselves rather than as the in-process loop: the pre-routing
 * single preset id reads as "legacy hosted engine" (it ran a hosted engine, the
 * id just never recorded which), and a session whose engine is not known — no
 * record, no preset, or no answer from the host — renders nothing, which is also
 * what the chip does until the host's first answer arrives.
 *
 * "What the session runs" is the ACTUAL engine, and for a live session that is
 * the agent in front of it rather than the plugin's record: a switch onto the
 * harness loop makes the host RELEASE the session's agent and reload the page,
 * and if that release did not take, the session keeps running the engine it had
 * while its record names another. This chip never renders the record as its name;
 * it appends the `切到 X · 尚未接管` marker beside the engine that really runs,
 * and its tooltip says what to do about it (`pendingSessionNotice`). See
 * `SessionEngineReport` in `src/agent-preset-ids.ts`.
 *
 * Styling is token-driven inline styles like the settings section (the
 * client-module bundle is esbuild-built without a CSS loader).
 * @module dsh-loop-engine/client/badge
 */
import type { JSX } from 'react';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionEngineCache, SessionSeat } from './session-engine.ts';
import { type en } from './locales.ts';
/** Registration-side business face for the header badge. */
export interface LoopEngineBadgeInjected {
    /** The plugin's authoritative per-session engine cache. */
    sessionEngines: SessionEngineCache;
    /** Section copy bound to the engine dictionaries. */
    t: (key: keyof typeof en) => string;
}
/**
 * Props delivered by the slot outlet (the renderer erases the share boundary).
 * The seat members stay partial here so the registration face matches the slot's
 * own props; {@link BadgeFace} asserts them the way the component reads them.
 */
export type LoopEngineBadgeProps = PropsRuntime<'conversation.session.header.actions'> & Partial<SessionSeat> & Partial<InjectFace<LoopEngineBadgeInjected>>;
/**
 * Render the session header's loop-engine chip for the session on screen.
 * @param props - composed slot props.
 * @returns the chip, or null when the seat carries no session to speak about or
 * the session's engine is not known yet (or not recorded at all).
 */
export declare function LoopEngineBadge(props: LoopEngineBadgeProps): JSX.Element | null;
//# sourceMappingURL=LoopEngineBadge.d.ts.map
/**
 * Composer loop-engine picker: a compact dropdown registered at the
 * `conversation.input.right` seat, so it sits immediately left of the model
 * select in the composer's tool row.
 *
 * It picks the engine of the session it is rendered in — the picker's value is
 * this plugin's own authoritative read of that session's engine, and a pick
 * moves the session over this plugin's own `loopEngine/select` Remote. Any
 * session can be moved, at any point in its life, as long as it is open and no
 * turn is in flight, and the host picks one of two ways to make the pick land:
 *
 *  - between two hosted engines it REBUILDS that session's agent IN PLACE, on the
 *    session's own live Session object, so the conversation it is rendered beside
 *    never closes;
 *  - when the harness loop is on either side of the change, the host RELEASES
 *    that session's agent and answers `reload: true`: the session goes cold with
 *    its record naming the new engine, this page is reloaded (which is what
 *    clears the client state a `session/disposed` leaves behind), and the page
 *    that comes back opens the same session again — the host then builds it on
 *    the engine the record names (`src/client/reload.ts`). This control says so
 *    in a notice rather than letting the reload look like a glitch.
 *
 * Either way the host refuses one that is
 * running, and a refusal leaves the session's engine untouched — the label goes
 * back to the engine the session actually runs. The refusal is rendered from its
 * CODE in the user's own language (`refusalFace`), with the host's own sentence
 * kept as detail — never as the message itself, which is how a raw
 * `session "…" is running; …` used to reach the user.
 *
 * A pick commits as soon as the host can apply it, with ONE exception: when the
 * target and the engine this session ACTUALLY runs differ in being the in-process
 * one, the host cannot hand the session over in place, so the switch releases its
 * agent and reloads this page — and a reload costs this page's scroll position and
 * any unsent draft in it. That one pick is staged behind a confirmation
 * (`switchNeedsReload(报告里的实际引擎, 目标引擎)`, resolved before anything is
 * sent) and only then committed; a pick between two hosted engines, which swaps
 * the agent in place and reloads nothing, still commits immediately and opens no
 * dialog at all. That judgement is only ever made about an engine somebody knows:
 * until the host has answered what this session runs there is no engine to judge,
 * and a session with no answer may reload in EITHER direction — so the control is
 * DISABLED for as long as it is reading (`engineSwitchReady`), rather than
 * guessing a direction. This control deliberately asks NOTHING else: whether the session
 * can be moved right now is the host's own judgement — it refuses one that is not
 * open, one that is mid-turn, and a subagent's own session, each with a code and a
 * sentence — so a pick that cannot land costs nothing, and the control never
 * reads an idle hint off a cached session list.
 *
 * So it opens two dialogs, with different jobs: the CONFIRMATION (two buttons,
 * cancel and switch) that a reloading pick must pass before it is sent, and the
 * NOTICE (one button, close) that reports what the host answered — the refusal's
 * localized copy with the host's sentence as detail, or this plugin's own
 * sentence for a reloaded pick.
 *
 * WITH a session, the settings default is never shown — not even while the first
 * answer is still in flight: a session on the pre-routing single preset id reads
 * "legacy hosted engine", one whose engine is not recorded (or not readable)
 * reads "not recorded", and a session whose engine has not been answered yet
 * reads "reading" AND is disabled while it does (see above) — a default or a stale
 * hint would be a claim about a session this control has no facts for, and a pick
 * would have to be judged against an engine nobody knows. Without a session (the
 * seat renders only with one, so this is the defensive branch) the trigger names
 * the default and a pick writes it — immediately, like every other pick here, and
 * with the control usable from the start: a new-session page is waiting for
 * nothing, and that pick reloads nothing. The settings section's own picker is the
 * one that still stages its choice behind a confirmation.
 *
 * Styling is token-driven inline styles like the badge and section (the
 * client-module bundle is esbuild-built without a CSS loader).
 * @module dsh-loop-engine/client/composer
 */
import { type JSX } from 'react';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { LoopEngineStore, LoopEngineState } from './store.ts';
import { type SessionEngineCache, type SessionEngineSwitcher, type SessionSeat } from './session-engine.ts';
import { type en } from './locales.ts';
/** Injected dependencies of {@link LoopEngineComposerSelect} (slot `inject`). */
export interface LoopEngineComposerSelectInjected {
    /** The selection store (loaded on mount, refreshed by scope pushes). */
    controller: LoopEngineStore;
    hooks: {
        /** Engine snapshot bound by the UI renderer as useSnapshot. */
        snapshot: SnapshotStore<LoopEngineState>;
    };
    /** The plugin's authoritative per-session engine cache. */
    sessionEngines: SessionEngineCache;
    /** Move one session to another engine. */
    switchEngine: SessionEngineSwitcher;
    /** Composer copy bound to the loop engine dictionaries. */
    t: (key: keyof typeof en) => string;
}
/**
 * Props delivered by the slot outlet (the renderer erases the share boundary).
 * The seat members stay partial here so the registration face matches the slot's
 * own props; {@link ComposerFace} asserts them the way the component reads them.
 */
export type LoopEngineComposerSelectProps = PropsRuntime<'conversation.input.right'> & Partial<SessionSeat> & Partial<InjectFace<LoopEngineComposerSelectInjected>>;
/**
 * Render the composer's loop-engine dropdown for the session on screen. Hides
 * until the settings scope settles, so the picker never flashes a provisional
 * default while a session's own engine is already known.
 * @param props - composed slot props.
 * @returns the picker, or null while the picker is unavailable or switched off.
 */
export declare function LoopEngineComposerSelect(props: LoopEngineComposerSelectProps): JSX.Element | null;
//# sourceMappingURL=LoopEngineComposerSelect.d.ts.map
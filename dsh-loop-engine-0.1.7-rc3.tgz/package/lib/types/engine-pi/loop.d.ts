/**
 * Pi loop engine module: drives every session it is handed through the Pi CLI
 * (`@earendil-works/pi-coding-agent`) over its JSONL RPC mode, one stateless
 * session per dsh step, with the durable session log as the sole source of
 * model context. The router routes a session here on the plugin's own engine
 * record, else its agent preset; this module is a library, not a Cordis plugin entry. Pi has no permission system, so the entire `pi --mode rpc` child is
 * spawned through the dsh subprocess seam — the only available privilege
 * boundary — and its `--tools` are pruned to the resolved sandbox stance.
 *
 * @module dsh-loop-engine/engine-pi
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { AgentOptions } from '@deepseek-ai/dsh-agent';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import { PiAgent } from './agent.ts';
import type { PiProcess, PiSpawnSpec } from './rpc/client.ts';
import type { PiSandboxMode, ResolvedConfig } from './types.ts';
import { HostedEngineRuntime } from '../driver-core/hosted-engine-runtime.ts';
/** Pi CLI sandbox modes a deployment may pin. */
export declare const PI_SANDBOX_MODES: readonly PiSandboxMode[];
/** Grace in milliseconds for Pi process-tree termination. */
export declare const PI_DISPOSE_GRACE_MS = 3000;
/** Deployment-owned configuration for the Pi loop plugin. */
export interface Config {
    /**
     * Pinned sandbox stance for every RPC child. When omitted, each query follows
     * the session's dsh permission knobs (`sandbox/mode` and `approval/policy`):
     * full access runs native, `workspace-write` wraps the child in the dsh
     * sandbox with a write-capable tool set, an `ask` policy degrades to a
     * read-only denial, and anything else fails closed with `read-only`.
     */
    sandboxMode?: PiSandboxMode;
    /** LLM provider for the `pi` child (`--provider`), when the deployment pins one. */
    provider?: string;
    /** Fallback model for the `pi` child (`--model`), used when the session selects none; Pi native settings own the model when omitted. */
    model?: string;
    /** Thinking/reasoning level, appended to the `--model` pattern when pinned. */
    thinkingLevel?: string;
    /** Explicit environment entries passed to the `pi` child. */
    env?: Record<string, string>;
}
/** Schema of the Pi loop plugin configuration. */
export declare const Config: z<Config>;
/** Host-face ctx key this engine's runtime is registered under. */
export declare const PI_ENGINE_LABEL = "agentLoopPi";
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentLoopPi: PiLoop;
    }
}
/**
 * Creation/resume machinery for the Pi engine. The process-wide AgentFactory
 * slot belongs to the router, which delegates each session to the engine its
 * preset names; this class is that engine's driver, not a plugin.
 */
export declare class PiLoop extends HostedEngineRuntime<ResolvedConfig, PiAgent> {
    /** Process-tree spawn capability handed to every agent, sandboxed by the subprocess seam. */
    readonly spawn: (spec: PiSpawnSpec) => PiProcess;
    /** Resolved Pi CLI entrypoint; `argv[0]` of every Pi RPC child. */
    readonly bin: string;
    constructor(ctx: Context, config: Config);
    /** Construct the Pi RPC driver for one prepared session. */
    protected buildAgent(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session): PiAgent;
}
//# sourceMappingURL=loop.d.ts.map
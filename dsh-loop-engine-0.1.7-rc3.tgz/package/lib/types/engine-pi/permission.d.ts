/**
 * Mapping from the dsh session's durable permission knobs to one Pi RPC
 * process's runtime stance. Pi carries no native permission system — "runs
 * with the permissions of the user" — so the driver cannot ask it to sandbox or
 * approve. What is left is the `--tools` allowlist: the child runs under the
 * dsh user either way (the subprocess seam carries no confinement of its own),
 * so withholding a tool IS the stance. The fold mirrors the codex bridge,
 * mapping the session's `sandbox/mode` and `approval/policy` events directly:
 *   - full access → `danger-full-access`, no pruning (Pi's native tools);
 *   - `workspace-write` → a write-capable set, still without a shell;
 *   - an `ask` policy → degraded to a read-only denial (Pi has no request
 *     callback, so interactive approval can only become a rejection);
 *   - anything else fails closed → `read-only`.
 *
 * @module dsh-loop-engine/engine-pi/permission
 */
import type { PermissionEvent } from '../driver-core/permission-knobs.ts';
import type { PiSandboxMode } from './types.ts';
/** The runtime stance one Pi RPC process should run under. */
export interface PiPermission {
    /** The resolved sandbox stance; selects the tool set, not a process sandbox. */
    readonly sandboxMode: PiSandboxMode;
    /** The `--tools` allowlist — the stance's only enforcement; empty means no pruning. */
    readonly tools: readonly string[];
}
/**
 * Conservative unattended default: read-only sandbox, no write/exec tools. The
 * allowlist names pi's built-ins (`read`, `bash`, `edit`, `write`) and nothing
 * else — a name pi does not know matches no tool at all, silently, so a list
 * carrying invented entries would enforce less than it claims to.
 */
export declare const DEFAULT_PI_PERMISSION: PiPermission;
/**
 * Derive the `--tools` allowlist for a given sandbox stance. Full access prunes
 * nothing; `workspace-write` allows a write-capable set; `read-only` allows
 * reading and nothing else. Only pi's own built-in tool names appear here.
 * @param mode - the resolved sandbox stance.
 * @returns the tool set to pass as `--tools`.
 */
export declare function toolsForSandbox(mode: PiSandboxMode): readonly string[];
/**
 * Resolve the session's effective Pi runtime stance.
 * @param events - the durable session log.
 * @returns the stance one Pi RPC process should run under.
 */
export declare function resolveSessionPermission(events: readonly PermissionEvent[]): PiPermission;
//# sourceMappingURL=permission.d.ts.map
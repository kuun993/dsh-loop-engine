/**
 * Pi's dialect for a dsh endpoint: a self-built agent directory plus the argv
 * flags that point the `pi --mode rpc` child at dsh's model.
 *
 * Pi resolves a model through its own agent directory — `models.json` under
 * `PI_CODING_AGENT_DIR` (or `~/.pi` when unset) — and its custom-provider schema
 * has no `apiKeyEnv`: a provider's credential is either a literal `apiKey` in
 * that file or the CLI's own `--api-key`. There is no `PI_*` variable for a base
 * URL either. So the only automatic way to hand pi a dsh endpoint is to give it
 * an agent directory THIS PLUGIN owns, containing a `models.json` that declares
 * the dsh provider, and to point `PI_CODING_AGENT_DIR` at it.
 *
 * The user's `~/.pi` is deliberately never written or read: the plugin owns a
 * separate directory under the OS temp dir, one per distinct endpoint, created
 * 0700 with a 0600 file because it carries the credential. The cost is real and
 * documented: redirecting the agent directory means the child no longer sees the
 * user's own `~/.pi` skills/auth/theme. That is the trade the deployment makes
 * by selecting a real dsh model on pi.
 *
 * pi's provider schema requires a wire protocol (`api`), so this is the one
 * engine that cannot express a handover without one; the driver drops such a
 * handover before it reaches here instead of writing a file pi rejects.
 *
 * @module dsh-loop-engine/engine-pi/model-handover
 */
import type { DshModelHandover } from '../driver-core/model-handover.ts';
/**
 * The agent directory for one handover, materialized on first use.
 *
 * The directory name is a hash of the endpoint facts, so two sessions on the
 * same provider/model share one directory and a changed endpoint gets its own;
 * `models.json` declares exactly the provider pi is told to use (`--provider`)
 * and the one model it is told to run (`--model`), keyed the way pi's own
 * schema reads it (`baseUrl`/`api`/`apiKey`/`models`).
 * @param handover - the resolved dsh endpoint for the session's selection.
 * @returns the absolute path to hand the child as `PI_CODING_AGENT_DIR`.
 */
export declare function piAgentDir(handover: DshModelHandover): string;
//# sourceMappingURL=model-handover.d.ts.map
/**
 * Pi loop Agent: drives one session through turn and step boundaries by
 * spawning a `pi --mode rpc` child process and speaking strict-LF JSONL over
 * stdio. The dsh session log is the sole source of truth and each step runs one
 * stateless Pi session (a fresh `new_session` + a single `prompt`), so the
 * prompt is a pure serialization of the durable history plus the assembled dsh
 * system prompt. Pi owns its tools natively but has no permission system, so
 * the whole child is sandboxed by the dsh subprocess seam and its `--tools`
 * are pruned to the resolved stance.
 *
 * @module dsh-loop-engine/engine-pi/agent
 */
import type { Agent, AgentCancelCause, AgentOptions, AgentStatus, CancelOptions, InboxTarget } from '@deepseek-ai/dsh-agent';
import type { Scope } from '@deepseek-ai/dsh-scope';
import type { Session, SessionId, UserMessage } from '@deepseek-ai/dsh-session';
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './types.ts';
import { DriverInbox } from '../driver-core/inbox.ts';
import { type PiSpawnCapability } from './rpc/client.ts';
/**
 * Provider route label this driver logs into request/header snapshots and
 * message provenance — the ONE route every hosted engine shares
 * ({@link HOSTED_ROUTE_LABEL}), so all four engines select `external/default`
 * and the model menu carries a single group instead of one per engine.
 */
export declare const PROVIDER = "external";
/** Drives one session through turn and step boundaries on Pi. */
export declare class PiAgent implements Agent {
    private loopCtx;
    readonly id: SessionId;
    readonly options: AgentOptions;
    readonly session: Session;
    private readonly config;
    private readonly spawn;
    private readonly bin;
    readonly inbox: DriverInbox;
    private phase;
    private activityDone;
    /** The agent-scoped registration boundary; the lifecycle owner unwinds it after the driver exits. */
    readonly scope: Scope;
    readonly ctx: Context;
    /** Fused dispatcher, built once in the constructor so hot-path dispatches never allocate. */
    private readonly dispatch;
    /** Whether this loop instance has appended its initial/resume request anchor. */
    private requestHeaderLogged;
    /** Agent-lifecycle-local counter naming each streamed attempt. */
    private streamAttempts;
    /** This step's RPC child; released by the step teardown and the scope teardown. */
    private rpc;
    /**
     * Tool results logged into the currently open step. A result means the
     * segment that requested the call is finished, so the next assistant content
     * opens the next step (see {@link beginSegment}).
     */
    private stepSettledTools;
    /**
     * Rotate to the next step when the segment that ran a tool has finished, so
     * each assistant segment lands in its own step.
     *
     * Called as new assistant content begins. A step holding a settled tool
     * result means the previous segment is complete, and the content about to be
     * written belongs to the next one. Rotating at a message boundary keeps calls
     * announced together — one model turn — in one step.
     * @param phase - the running phase carrying the open step's position.
     */
    private beginSegment;
    constructor(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session, config: ResolvedConfig, spawn: PiSpawnCapability, bin: string);
    /**
     * Open this step's RPC child. The Pi RPC process is single-session, so a step
     * never reuses one: the step teardown disposes it and the next step respawns
     * a fresh child.
     */
    private rpcClient;
    get status(): AgentStatus;
    /** Commit a phase and publish its externally visible status transition. */
    private setPhase;
    send(message: UserMessage, target: InboxTarget, wakeup: boolean): void;
    /**
     * Queue a message for the next turn and wake the driver.
     * @param input - the user message to deliver.
     */
    followup(input: UserMessage): void;
    /**
     * Queue a message for the running step and wake the driver.
     * @param input - the user message to deliver.
     */
    steer(input: UserMessage): void;
    /**
     * Queue a message for the running step without waking the driver.
     * @param input - the user message to deliver.
     */
    inject(input: UserMessage): void;
    cancel(cause: AgentCancelCause, options?: CancelOptions): void;
    /**
     * Run a maintenance job while the agent is idle.
     * @param job - the maintenance operation, receiving the phase abort signal.
     * @returns the maintenance result.
     */
    runMaintenance<T>(job: (signal: AbortSignal) => Promise<T>): Promise<T>;
    /**
     * Start one driver, or latch its wake behind maintenance or an aborted
     * activity. A wake sent while idle always opens its turn boundary, even
     * when its message was cleared; only a latched replay is suppressed when
     * the queue no longer holds the wake.
     * @param wakeAfterAbort - the {@link send} classification, captured before
     *   the inbox insertion so a reentrant cancel cannot reclassify it.
     */
    private wakeDriver;
    whenIdle(): Promise<void>;
    /** Report one failure at its live boundary, then preserve it for driver containment. */
    private throwError;
    private kick;
    private preStep;
    /**
     * Scan the step's user messages for `/name` skill gestures, load each
     * matching skill, and inject the rendered skill content into the message
     * batch.  This mirrors what dsh-tool-skill does for the in-process engine.
     * @param messages - the current step's message batch.
     * @param signal - cancellation signal (aborted loads are silently dropped).
     * @returns the original batch when no skill was invoked, or an extended
     *   batch with injected skill-content messages appended.
     */
    private injectSkills;
    /**
     * Resolve the runtime permission stance for one query. Deployment-pinned
     * fields win; anything unpinned follows the session's durable dsh permission
     * knobs, re-folded per query so mid-session preset switches take effect on the
     * next step.
     * @returns the permission fields of the query spec.
     */
    private queryPermission;
    /** Open one turn before claiming its first proposed step. */
    private turn;
    /** Model label recorded in the request header for one lifecycle. */
    private modelLabel;
    /** Append the request header snapshot once per loop instance. */
    private assertRequestHeader;
    /**
     * Build the `pi --mode rpc` argv/cwd/env for one step's child process.
     *
     * The model comes from the session's own selection when it names a real dsh
     * model, else from the deployment's pinned configuration
     * ({@link sessionModelOverrideOf}). Pi's `--model` flag is
     * `"provider/id"`-qualified, so a session pick travels as the composite —
     * which also carries the provider, leaving the deployment's `--provider` out
     * of the argv for that step. A step with neither a selection nor a pin sends
     * no `--model` at all and lets Pi's own configuration decide. Read every step,
     * so a model picked mid-conversation lands on the next child.
     *
     * When dsh also discloses that model's ENDPOINT, the child is pointed at it:
     * `--provider` names the provider pi's `models.json` declares, `--api-key`
     * carries the credential, and `PI_CODING_AGENT_DIR` redirects pi's agent
     * directory to the plugin-owned one holding that `models.json`
     * ({@link piAgentDir}) — so the child runs on dsh's endpoint instead of its
     * own `~/.pi` configuration, which is never touched.
     */
    private spawnSpec;
    /**
     * Run one Pi RPC query for the current step and map its event stream into the
     * session log. The step opens a fresh Pi session (`new_session`) and sends the
     * serialized session history as one prompt, then consumes events until the
     * agent settles. Like the Codex/Claude drivers, Pi owns its own system prompt
     * natively, so the dsh system-prompt assembly (which pulls dsh tool schemas
     * and `agent.ctx.tools`) is deliberately not run — the durable session log is
     * the sole source of model context.
     */
    private step;
    /** Append one Pi tool result to the durable log as a `tool/result` message. */
    private appendToolResult;
}
//# sourceMappingURL=agent.d.ts.map
import type { PiProcess, PiSpawnSpec } from './rpc/client.ts';
/** One discoverable Pi model: the raw two-part identity `pi` exposes. */
export interface PiModelEntry {
    readonly provider: string;
    readonly model: string;
}
/**
 * Parse the output of `pi --list-models`: a column-aligned table whose first
 * two columns are `provider` and `model`. The header row and blank lines are
 * skipped; long model ids simply occupy more columns. Splitting on 2+ spaces
 * yields provider and model in the first two fields regardless of alignment.
 */
export declare function parsePiModelList(output: string): PiModelEntry[];
/**
 * Spawn `pi --list-models` and return the parsed model entries. Failures
 * (non-zero exit, no stdout, spawn throw) resolve to an empty array so the
 * catalog stays advisory and a probe glitch never breaks the engine mount.
 * @param bin - the Pi CLI entrypoint (from `piCliEntrypoint()`); becomes spec.argv[0].
 * @param spawn - the process-spawn adapter; `piSubprocessSpec` prepends the node
 *   prefix, so spec.argv must NOT carry it.
 */
export declare function probePiModels(bin: string, spawn: (spec: PiSpawnSpec) => PiProcess): Promise<readonly PiModelEntry[]>;
//# sourceMappingURL=probe.d.ts.map
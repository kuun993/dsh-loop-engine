/**
 * Shared loop-engine identity, namespaces, and schemas.
 *
 * Both the namespace literals and the engine/preset-id mapping live in
 * zero-import modules (`./namespace.ts`, `./agent-preset-ids.ts`) so both halves
 * agree on them: the node half brands the literal as a `SettingsNamespace` and
 * builds these schemas, while the browser half imports the same literals
 * without pulling host-side packages (`dsh-settings`, `schemastery`, `node:fs`)
 * into the client bundle (cross-plugin value imports go through cordis
 * services). This module re-exports them so node-side importers keep their
 * paths.
 *
 * The two live schema families exist because one build serves two harness
 * generations: the 0.1.5 line addresses a settings SECTION registered by a
 * provider under a namespace string ({@link LOOP_ENGINE_SETTINGS_SCHEMA} via
 * {@link loopEngineSettingsNamespace}), while the 0.1.7 line makes the plugin's
 * two live fields profile-backed Config entries
 * ({@link LOOP_ENGINE_ENGINE_SCHEMA} / {@link LOOP_ENGINE_SHOW_IN_COMPOSER_SCHEMA}).
 * Which family a running plugin builds is decided by `./compat.ts`
 * (`LEGACY_HARNESS`) in `./index.ts`.
 *
 * @module dsh-loop-engine/settings
 */
import z from '@deepseek-ai/schemastery';
import type { SettingsNamespace } from '@deepseek-ai/dsh-settings';
import type { LoopEngineId } from './agent-preset-ids.ts';
export { LOOP_ENGINE_SETTINGS_NAMESPACE_LITERAL, LEGACY_LOOP_ENGINE_SETTINGS_NAMESPACE_LITERAL } from './namespace.ts';
export { HOSTED_ENGINE_IDS, HOSTED_PRESET_PREFIX, LOOP_ENGINE_IDS, SOURCE_PRESET_ID, engineOfPreset, enginePresetId, } from './agent-preset-ids.ts';
export type { HostedEngineId, LoopEngineId } from './agent-preset-ids.ts';
/** Stored and composed loop engine selection. */
export interface LoopEngineSettings {
    /** The engine NEW sessions are created on; the engine a given session runs is the plugin's own per-session record. */
    engine: LoopEngineId;
    /** Whether the composer's loop engine picker is shown on the chat page. */
    showInComposer: boolean;
}
/**
 * Schema of the loop engine settings section, as the 0.1.5 line's settings host
 * consumes it. The engine union derives from {@link LOOP_ENGINE_IDS}, so adding
 * an engine there also admits it here.
 */
export declare const LOOP_ENGINE_SETTINGS_SCHEMA: z<LoopEngineSettings>;
/** The 0.1.5-line namespace branded as a settings namespace on the node side. */
export declare function loopEngineSettingsNamespace(): SettingsNamespace;
/**
 * Live Config field schema for the default engine (0.1.7 line). `.volatile()`
 * declares it profile-backed: the settings shell projects it as a form field,
 * and a committed edit reaches the running plugin through the live Config
 * reference. The engine union derives from {@link LOOP_ENGINE_IDS}, so adding
 * an engine there admits it here too.
 */
export declare const LOOP_ENGINE_ENGINE_SCHEMA: z<"in-process" | "claude-code" | "codex" | "pi" | "kimi", "in-process" | "claude-code" | "codex" | "pi" | "kimi", "volatile-defined">;
/** Live Config field schema for the composer picker toggle (0.1.7 line). */
export declare const LOOP_ENGINE_SHOW_IN_COMPOSER_SCHEMA: z<boolean, boolean, "volatile-defined">;
//# sourceMappingURL=settings.d.ts.map
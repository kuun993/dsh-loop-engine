/**
 * Hosted-engine agent presets: one managed copy of the deployment's `standard`
 * preset per hosted engine, with the dsh-native command and skill rows
 * stripped.
 *
 * A hosted engine (Claude Code, Codex, Pi, Kimi) owns its session's command
 * and skill surface: the plugin bridges the engine's own slash commands and
 * skill providers into the session (see `engine-surface.ts`), and the
 * dsh-native equivalents would only duplicate or mislead — dsh `/plan` is
 * advisory prompt text an external engine never assembles, dsh `/compact`
 * cannot shrink a context the engine's child process holds, and dsh skills
 * would sit next to the engine's own catalog. Those rows live inside the
 * agent-preset composition, which a profile patch cannot reach, so the plugin
 * authors a stripped preset per engine into the user preset root
 * (`$DSH_HOME/.agent-presets/<id>`).
 *
 * The preset id is ALSO the per-session engine selector: the harness resolves
 * one preset per session and hands its id to the agent factory at create time
 * (`CreateAgentOptions.meta.agentPreset`), which is the only per-session
 * channel that reaches agent creation. One preset per engine is therefore what
 * makes "session A on Codex, session B on Kimi, concurrently" expressible in a
 * harness that admits exactly one AgentFactory.
 *
 * The presets are REGENERATED from the current `standard` composition on every
 * boot: text on disk is never authoritative, so a harness upgrade that changes
 * `standard` flows through. The file is plain YAML the loader already accepts —
 * the strip is a line transform that preserves everything it does not drop byte
 * for byte, comments included.
 *
 * @module dsh-loop-engine/preset
 */
export { HOSTED_PRESET_PREFIX, SOURCE_PRESET_ID, engineOfPreset, enginePresetId, hostedEngineOf, sessionEngineOf, } from './agent-preset-ids.ts';
export type { SessionEngine } from './agent-preset-ids.ts';
/** Harness-home-relative directory of locally authored presets (mirrors `USER_PRESET_DIR` in `dsh-agent-presets`). */
export declare const USER_PRESET_DIR = ".agent-presets";
/** The composition file that makes a directory a preset. */
export declare const COMPOSITION_FILE = "agent.cordis.yml";
/** The display-metadata file beside a preset's composition. */
export declare const METADATA_FILE = "preset.yml";
/** Every preset id this plugin owns, whether or not it is currently authored. */
export declare const HOSTED_PRESET_IDS: readonly string[];
/**
 * Top-level rows stripped from the source preset for hosted engines:
 * - `skill-filesystem` / `tool-skill`: the dsh skill surface — each engine
 *   registers its own skill provider in the session's agent scope;
 * - `tool-goal` / `command-goal`: dsh's goal mode. The model-facing tool only
 *   works while an in-process loop drives the session, and the human command
 *   would sit in the menu with nothing behind it — no hosted engine here
 *   implements `/goal`, so there is nothing for it to hand over to. The
 *   `command-goal` row lives HERE, in the preset layer, because that is where
 *   the human command is registered; disabling the host-plane row from the
 *   profile patch does not reach it (`standard` carries its own row);
 * - `planning`: dsh plan mode — its only model-visible effect is a system
 *   prompt section an external engine never assembles;
 * - `compaction`: dsh `/compact` and auto-compaction — a hosted engine owns
 *   its context and its own `/compact` (Claude, Kimi).
 */
export declare const STRIPPED_ROWS: readonly ["skill-filesystem", "tool-skill", "tool-goal", "command-goal", "planning", "compaction"];
/**
 * Remove top-level entries by id from a preset composition, preserving every
 * other byte. Each entry owns the comment/blank run directly above its opener
 * — that run is the entry's section heading and drops with it — except the
 * run above the FIRST entry, which is the file header and stays. Entries
 * without an `id` opener are always kept: the transform touches only what it
 * can name.
 * @param text - the source composition.
 * @param ids - top-level row ids to strip.
 * @returns the stripped composition.
 */
export declare function stripPresetRows(text: string, ids?: readonly string[]): string;
/** Minimal read seam over the host's preset roster, per harness generation. */
export interface PresetCompositionSource {
    /** 0.1.5 line: read one preset's composition text; throws when the id is unknown. */
    read?(id: string): Promise<string>;
    /** 0.1.7 line: read one preset's document; `content` is the composition text. */
    readDocument?(id: string): Promise<{
        readonly content: string;
    }>;
}
/**
 * Regenerate every hosted engine's preset under the dsh home's user preset root
 * from the roster's `standard` preset. Idempotent: an up-to-date directory is
 * untouched, so no standing mount sees a spurious file-stamp change.
 * @param dshHome - the resolved harness home.
 * @param source - the roster's composition reader.
 * @returns whether any file was written.
 * @throws when the source preset cannot be read or the writes fail.
 */
export declare function ensureEnginePresets(dshHome: string, source: PresetCompositionSource): Promise<boolean>;
//# sourceMappingURL=preset.d.ts.map
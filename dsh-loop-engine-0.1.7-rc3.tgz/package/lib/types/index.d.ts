/**
 * Per-session agent loop engines, node half.
 *
 * Hosts the non-default agent-loop engines (Claude Code, Codex, Pi, Kimi Code)
 * and routes each session to the engine it runs. The engine is the PLUGIN's own
 * per-session fact (`session-engine-store.ts`), read first and over the recorded
 * agent preset; a session the plugin has no record for keeps the preset answer,
 * which is what makes every pre-existing session behave exactly as before.
 * The harness admits exactly one AgentFactory per process, so "session A on
 * Codex while session B runs Kimi" is realized by a single router factory
 * ({@link RouterLoop}, which extends the harness's own `AgentLoop`) dispatching
 * to one driver runtime per engine; `in-process` sessions keep the harness loop
 * through that same router.
 *
 * Because the router owns the slot, the plugin keeps the base bundle's
 * `agent-loop` row disabled for as long as it is composed. That managed block
 * lives in the profile's `cordis.patch.yml` (see `patch-manager.ts`) and is the
 * plugin's only footprint in the harness's configuration; the block names no
 * engine, because the engine is a per-session decision.
 *
 * The plugin authors one preset per hosted engine into the user preset root
 * (`$DSH_HOME/.agent-presets/loop-engine-<engine>`, see `preset.ts`), each a
 * copy of `standard` minus the dsh-native command and skill rows an external
 * engine replaces, and it serves every hosted engine's provider route label in
 * the llm registry (`provider-route.ts`): an engine logs its own label into
 * each session's request/header, and the web host refuses a turn whose session
 * selection names a provider no adapter serves. The preset is now only the
 * session's agent-plane composition (and the engine's own default for a session
 * with no record) — it is no longer the thing that decides a running session's
 * engine.
 *
 * The plugin's own live `engine` Config field carries the DEFAULT engine for new
 * sessions — which preset the roster's default points at — not a process-wide
 * switch: existing sessions keep the engine they run, and nothing is torn down or
 * reloaded by it. (A PER-SESSION switch is a different thing: it is made from the
 * chat composer, and when it involves the harness loop it releases that session's
 * agent and reloads the page — `router-loop.ts` `move`, `client/reload.ts`.)
 *
 * @module dsh-loop-engine
 */
import type { Context, Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type Config as ClaudeCodeConfig } from './engine-claude/loop.ts';
import type { CodexApprovalPolicy, CodexSandboxMode } from './engine-codex/types.ts';
import { type LoopEngineId } from './settings.ts';
export declare const name = "loop-engine";
/**
 * Services the plugin's own fiber requires. The plugin declares none of its
 * own: the optional host services it reads (`commands`, `skills`, `agentPresets`,
 * `llm`) are resolved lazily via `ctx.get` and may be absent, and the router
 * declares the harness loop's own dependency set when it mounts. Empty keeps
 * the plugin from demanding a service that a minimal profile does not provide.
 */
export declare const inject: never[];
/** Composition entry for the loop engine selection and the hosted engine drivers. */
export interface Config extends ClaudeCodeConfig {
    /** Profile whose `cordis.patch.yml` carries the managed block; defaults to `web`. */
    profile?: string;
    /** Patch file name inside the profile; defaults to `cordis.patch.yml`. */
    patchFilename?: string;
    /** Explicit absolute path to the patch file, overriding profile + filename. */
    patchPath?: string;
    /** Pinned Codex sandbox mode; falls back to the session's dsh permission knobs. */
    sandboxMode?: CodexSandboxMode;
    /** Pinned Codex approval policy; falls back to the session's dsh permission knobs. */
    approvalPolicy?: CodexApprovalPolicy;
    /** LLM provider for the Pi RPC child (`--provider`). */
    piProvider?: string;
    /** Thinking/reasoning level for the Pi RPC child, appended to its `--model`. */
    piThinking?: string;
    /** Kimi CLI executable; `'kimi'` resolves through PATH when not pinned to an absolute path. */
    kimiBin?: string;
    /**
     * Default engine NEW sessions are created on. A live, profile-backed field:
     * the settings shell edits it and the running plugin reads it through this
     * volatile reference (`config.engine.get()`).
     */
    engine: Volatile<LoopEngineId>;
    /** Whether the chat composer shows the engine picker; a live, profile-backed field. */
    showInComposer: Volatile<boolean>;
}
/** Rejected input of the composition entry: live fields arrive as plain values and resolve to references. */
type ConfigInput = Omit<Config, 'engine' | 'showInComposer'> & {
    engine?: LoopEngineId;
    showInComposer?: boolean;
};
/**
 * Schema of the loop engine composition entry.
 *
 * A schemastery object validates each field only when it is present and lets
 * an absent key fall through as `undefined`, so omitted knobs are accepted —
 * matching the permissive interface and read path (`resolvePatchPath` defaults
 * the patch path; each engine driver resolves only the knobs it owns and
 * omitted deployment tunables fall back to the session). The composition entry
 * is an engine-agnostic superset: every hosted engine's knobs live here at
 * once, because any session may select any engine.
 *
 * On the 0.1.7 line `engine` and `showInComposer` are the entry's live fields:
 * `.volatile()` makes them profile-backed settings the settings shell projects
 * as form fields, and the runtime reads each one through its reference
 * (`config.engine.get()`). On the 0.1.5 line there are no live Config fields —
 * the selection is a settings section (`LOOP_ENGINE_SETTINGS_SCHEMA`), whose
 * provider owns the storage — so the entry is the engine knobs alone.
 */
export declare const Config: z<ConfigInput, Config>;
/** Resolve the managed patch file from configuration, defaulting to the web profile. */
export declare function resolvePatchPath(config: Config): string;
/** Atomically replace the patch file (same-directory temp + rename). */
export declare function writePatchFile(path: string, text: string): Promise<void>;
/**
 * Synchronously atomically replace the patch file. The settings onChange that
 * commits a default-engine change is a synchronous hook with no await, and the
 * write MUST land before the caller is told the change committed — otherwise a
 * user who restarts `dsh web` immediately reads the stale file.
 * @param path - the profile's patch file.
 * @param text - the next file content.
 */
export declare function writePatchFileSync(path: string, text: string): void;
/**
 * Ensure the profile's patch file carries the plugin's managed block, which
 * disables the base bundle's `agent-loop` row so this plugin's router owns the
 * single AgentFactory slot. Idempotent: a file already carrying a block and no
 * legacy block is left untouched.
 * @param path - the profile's patch file.
 * @returns whether a write occurred.
 */
export declare function syncManagedBlock(path: string): Promise<boolean>;
/**
 * Apply the plugin: own the profile's managed block, mount the routing factory,
 * author the per-engine presets, and serve every hosted engine's provider
 * route. The settings section carries the deployment's default engine.
 * @param ctx - the composing context.
 * @param config - composition entry for the managed patch file and engine knobs.
 */
export declare function apply(ctx: Context, config: Config): void;
export {};
//# sourceMappingURL=index.d.ts.map
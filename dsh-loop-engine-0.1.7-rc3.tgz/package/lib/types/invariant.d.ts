/**
 * Package-owned invariant companion for the loop engine selection.
 *
 * The plugin's owned relationship is the patch-manager round trip: applying the
 * managed block must be a fixed point, the block must be the one that frees the
 * single AgentFactory slot for the router, a legacy block naming a single engine
 * must be migrated to the engine-agnostic form while still being readable as a
 * legacy pin, and a comment-only layer must be re-seeded to a loadable
 * top-level array rather than left as `null`. The companion asserts those
 * against the pure transform, binding the writer's inverse to the reader
 * directly.
 *
 * @module dsh-loop-engine/invariant
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "loop-engine-invariant";
/** Services required before the companion can register. */
export declare const inject: string[];
/**
 * Register the loop-engine invariant contribution.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map
/**
 * Codex loop Agent: drives one session through turn and step boundaries by
 * spawning a `codex app-server` child process and speaking JSON-RPC over stdio.
 * Codex owns its prompt, tools, and sandbox; the durable session log remains
 * the source of truth and the thread input is a pure serialization of it.
 * The app-server streams token-level deltas via `item/agentMessage/delta` and
 * `item/reasoning/summaryTextDelta`, so the visible partial paints
 * progressively as the model generates — not all at once at the end. Native
 * approval requests (the `item/…/requestApproval` family) are server-initiated
 * requests, not notifications: the client answers them through the dsh approval
 * seam (`agent/requestPermission` → `ctx.approval`), while the thread still
 * starts with a declarative `sandboxMode`/`approvalPolicy` stance.
 *
 * @module dsh-loop-engine/engine-codex/agent
 */
import type { Agent, AgentCancelCause, AgentOptions, AgentStatus, CancelOptions, InboxTarget } from '@deepseek-ai/dsh-agent';
import type { Scope } from '@deepseek-ai/dsh-scope';
import type { Session, SessionId, UserMessage } from '@deepseek-ai/dsh-session';
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './types.ts';
import { DriverInbox } from '../driver-core/inbox.ts';
/**
 * Provider route label this driver logs into request/header snapshots and
 * message provenance — the ONE route every hosted engine shares
 * ({@link HOSTED_ROUTE_LABEL}), so all four engines select `external/default`
 * and the model menu carries a single group instead of one per engine.
 */
export declare const PROVIDER = "external";
/** Drives one session through turn and step boundaries on Codex. */
export declare class CodexAgent implements Agent {
    private loopCtx;
    readonly id: SessionId;
    readonly options: AgentOptions;
    readonly session: Session;
    private readonly config;
    readonly inbox: DriverInbox;
    private phase;
    private activityDone;
    /** The agent-scoped registration boundary; the lifecycle owner unwinds it after the driver exits. */
    readonly scope: Scope;
    readonly ctx: Context;
    /** Fused dispatcher, built once in the constructor so hot-path dispatches never allocate. */
    private readonly dispatch;
    /** Whether this loop instance has appended its initial/resume request anchor. */
    private requestHeaderLogged;
    /** Agent-lifecycle-local counter naming each streamed attempt. */
    private streamAttempts;
    /**
     * Tool results logged into the currently open step. A result means the
     * segment that requested the call is finished, so the next assistant content
     * opens the next step (see {@link beginSegment}).
     */
    private stepSettledTools;
    /**
     * Rotate to the next step when the segment that ran a tool has finished, so
     * each assistant segment lands in its own step.
     *
     * Called as new assistant content begins. A step holding a settled tool
     * result means the previous segment is complete, and the content about to be
     * written belongs to the next one. Rotating here (rather than when a call is
     * announced) keeps calls announced together — one model turn — in one step.
     * @param phase - the running phase carrying the open step's position.
     */
    private beginSegment;
    /** Lazily created app-server client, reused across steps and released on scope teardown. */
    private appServer;
    /**
     * The spawn configuration (`argv` + `env`) the cached client was built from.
     * Codex's endpoint lives in the child's own command line, so a handover change
     * must respawn the child rather than reuse one configured for another endpoint.
     */
    private appServerConfig;
    constructor(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session, config: ResolvedConfig);
    /**
     * Return the cached app-server client, spawning one on first use, after a dead
     * process, or when the resolved dsh endpoint changed since the last spawn.
     *
     * A handover is codex's own `-c` configuration for a dsh provider, so a
     * different endpoint (different provider, base URL, protocol, or credential)
     * needs a different child — the config is fixed when the process starts.
     * @param handover - the session's resolved dsh endpoint, or undefined to leave codex to its own configuration.
     */
    private appServerClient;
    /**
     * Answer one server-initiated interaction. Approvals go through the dsh
     * approval seam; a `request_user_input` question goes to the user-questions
     * seam (both fail closed when their seam is absent), and an MCP elicitation is
     * declined outright. Anything else is a protocol error.
     * @param method - the server request method.
     * @param params - the server request params.
     * @returns the JSON-RPC outcome to send back.
     */
    private answerRequest;
    /** Resolve one native Codex approval request through the dsh approval seam. */
    private answerApproval;
    /**
     * Put one `request_user_input` question to the human through the dsh
     * user-questions seam. The seam itself fails closed (`NO_PROVIDER`) when no
     * answerer is composed, so a refusal degrades to "no answers given" and the
     * turn continues; asking is never silently skipped, and the degradation is
     * logged rather than swallowed.
     * @param params - the request params carrying the questions.
     * @returns the response payload (or the empty answer when nobody answered).
     */
    private answerUserInput;
    /** Ask the dsh approval seam; fail closed to a denial when it is absent. */
    private requestApproval;
    get status(): AgentStatus;
    /** Commit a phase and publish its externally visible status transition. */
    private setPhase;
    send(message: UserMessage, target: InboxTarget, wakeup: boolean): void;
    /**
     * Queue a message for the next turn and wake the driver.
     * @param input - the user message to deliver.
     */
    followup(input: UserMessage): void;
    /**
     * Queue a message for the running step and wake the driver.
     * @param input - the user message to deliver.
     */
    steer(input: UserMessage): void;
    /**
     * Queue a message for the running step without waking the driver.
     * @param input - the user message to deliver.
     */
    inject(input: UserMessage): void;
    cancel(cause: AgentCancelCause, options?: CancelOptions): void;
    /**
     * Run a maintenance job while the agent is idle.
     * @param job - the maintenance operation, receiving the phase abort signal.
     * @returns the maintenance result.
     */
    runMaintenance<T>(job: (signal: AbortSignal) => Promise<T>): Promise<T>;
    /**
     * Start one driver, or latch its wake behind maintenance or an aborted
     * activity. A wake sent while idle always opens its turn boundary, even
     * when its message was cleared; only a latched replay is suppressed when
     * the queue no longer holds the wake.
     * @param wakeAfterAbort - the {@link send} classification, captured before
     *   the inbox insertion so a reentrant cancel cannot reclassify it.
     */
    private wakeDriver;
    whenIdle(): Promise<void>;
    /** Report one failure at its live boundary, then preserve it for driver containment. */
    private throwError;
    private kick;
    private preStep;
    /**
     * Scan the step's user messages for `/name` skill gestures, load each
     * matching skill, and inject the rendered skill content into the message
     * batch.  This mirrors what dsh-tool-skill does for the in-process engine.
     * @param messages - the current step's message batch.
     * @param signal - cancellation signal (aborted loads are silently dropped).
     * @returns the original batch when no skill was invoked, or an extended
     *   batch with injected skill-content messages appended.
     */
    private injectSkills;
    /**
     * Resolve the declarative permission stance for one query. Deployment-pinned
     * fields win per field; anything unpinned follows the session's durable dsh
     * permission knobs, re-folded per query so mid-session preset switches take
     * effect on the next step.
     * @returns the permission fields of the query spec.
     */
    private queryPermission;
    /** Open one turn before claiming its first proposed step. */
    private turn;
    /** Model label recorded in the request header for one lifecycle. */
    private modelLabel;
    /** Append the request header snapshot once per loop instance. */
    private assertRequestHeader;
    /** Run one Codex thread for the current step and map its transcript into the session log. */
    private step;
}
//# sourceMappingURL=agent.d.ts.map
/**
 * Codex loop engine module: drives every session it is handed through the
 * OpenAI Codex SDK, one stateless thread per dsh step, with the durable
 * session log as the sole source of model context. The router routes a session
 * here on the plugin's own engine record, else its agent preset; this module is
 * a library, not a Cordis plugin entry. The Codex SDK spawns its own CLI binary
 * (no spawn injection seam), so this loop deliberately does not inject the dsh
 * subprocess service.
 *
 * @module dsh-loop-engine/engine-codex
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { AgentOptions } from '@deepseek-ai/dsh-agent';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import { CodexAgent } from './agent.ts';
import type { CodexApprovalPolicy, CodexSandboxMode, ResolvedConfig } from './types.ts';
import { HostedEngineRuntime } from '../driver-core/hosted-engine-runtime.ts';
/** Codex CLI sandbox modes a deployment may pin. */
export declare const CODEX_SANDBOX_MODES: readonly CodexSandboxMode[];
/** Codex CLI approval policies a deployment may pin. */
export declare const CODEX_APPROVAL_POLICIES: readonly CodexApprovalPolicy[];
/** Deployment-owned configuration for the Codex loop plugin. */
export interface Config {
    /**
     * Pinned sandbox mode for every thread. When omitted, each query follows the
     * session's dsh permission knobs (`sandbox/mode` and `approval/policy`):
     * full access maps to `danger-full-access`, an `ask` policy maps to
     * `workspace-write`, and anything else fails closed with `read-only`.
     */
    sandboxMode?: CodexSandboxMode;
    /**
     * Pinned approval policy for every thread. When omitted, each query follows
     * the session's dsh permission knobs: an `ask` policy maps to `on-request`
     * (the CLI's own interactive prompt degrades to a denial in the unattended
     * dsh runtime) and anything else maps to `never`.
     */
    approvalPolicy?: CodexApprovalPolicy;
    /** Explicit environment entries layered over the credential-scrubbed parent environment. */
    env?: Record<string, string>;
    /** Fallback model for the app-server thread, used when the session selects none; Codex native settings own the model when omitted. */
    model?: string;
}
/** Schema of the Codex loop plugin configuration. */
export declare const Config: z<Config>;
/** Host-face ctx key this engine's runtime is registered under. */
export declare const CODEX_ENGINE_LABEL = "agentLoopCodex";
declare module '@deepseek-ai/cordis' {
    interface Context {
        agentLoopCodex: CodexLoop;
    }
}
/**
 * Creation/resume machinery for the Codex engine. The process-wide
 * AgentFactory slot belongs to the router, which delegates each session to the
 * engine its preset names; this class is that engine's driver, not a plugin.
 */
export declare class CodexLoop extends HostedEngineRuntime<ResolvedConfig, CodexAgent> {
    constructor(ctx: Context, config: Config);
    /** Construct the Codex driver for one prepared session. */
    protected buildAgent(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session): CodexAgent;
}
//# sourceMappingURL=loop.d.ts.map
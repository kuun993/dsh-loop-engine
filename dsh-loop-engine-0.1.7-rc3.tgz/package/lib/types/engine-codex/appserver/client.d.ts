/**
 * JSON-RPC client over stdio for the codex app-server. Spawns
 * `codex app-server` as a child process, sends JSON-RPC 2.0 requests over
 * stdin, and reads newline-delimited JSON responses/notifications from stdout.
 *
 * @module dsh-loop-engine/engine-codex/appserver/client
 */
import type { InitializeResult, ThreadResumeParams, ThreadStartParams, ThreadStartResult, TurnInterruptParams, TurnStartParams, TurnStartResult } from './types.ts';
/** Callback for receiving server notifications. */
export type NotificationHandler = (method: string, params: unknown) => void;
/** A JSON-RPC reply the client writes back for one inbound server request. */
export type RequestOutcome = {
    readonly result: unknown;
} | {
    readonly error: {
        readonly code: number;
        readonly message: string;
    };
};
/** Callback answering one server-initiated JSON-RPC request. */
export type RequestHandler = (method: string, params: unknown, id: number | string) => RequestOutcome | Promise<RequestOutcome>;
/** Callback for receiving raw stderr lines from the server process. */
export type StderrHandler = (line: string) => void;
/** JSON-RPC client for the codex app-server. */
export declare class AppServerClient {
    private process;
    private rl;
    private reqId;
    private pending;
    private notificationHandler;
    private requestHandler;
    private stderrHandler;
    private disposed;
    /** Whether this client was disposed or its server process exited. */
    get closed(): boolean;
    /** Create a client by spawning `codex app-server`. */
    private constructor();
    /**
     * Spawn the pinned app-server dependency and initialize the client.
     *
     * `argv` appends the driver's own overrides to the bare `app-server`
     * subcommand (codex's `-c key=value` configuration), and `env` layers the
     * driver's explicit entries over the ambient environment — the child still
     * needs `PATH` and, under a user's own codex setup, the ambient auth facts its
     * configuration reads, so this is an overlay, not a replacement. Both default
     * to nothing, which is the bare `codex app-server` the driver used before a
     * dsh endpoint was ever handed over.
     * @param argv - extra arguments after the `app-server` subcommand.
     * @param env - explicit environment entries layered over the ambient one.
     * @returns the initialized client.
     */
    static create(argv?: readonly string[], env?: NodeJS.ProcessEnv): Promise<AppServerClient>;
    /** Set the notification handler for streaming events. */
    onNotification(handler: NotificationHandler): void;
    /** Set the handler for server-initiated requests (e.g. approvals). */
    onRequest(handler: RequestHandler): void;
    /** Set the stderr handler for server log lines. */
    onStderr(handler: StderrHandler): void;
    /** Send the initialize handshake. */
    initialize(): Promise<InitializeResult>;
    /** Create a new thread. */
    threadStart(params: ThreadStartParams): Promise<ThreadStartResult>;
    /** Resume an existing thread. */
    threadResume(params: ThreadResumeParams): Promise<ThreadStartResult>;
    /** Start a turn with the given input. */
    turnStart(params: TurnStartParams): Promise<TurnStartResult>;
    /** Interrupt an active turn. */
    turnInterrupt(params: TurnInterruptParams): Promise<unknown>;
    /** Dispose the client and kill the server process. */
    dispose(): void;
    /** Send a JSON-RPC request and wait for the response. */
    private request;
    /** Handle one line of stdout from the server. */
    private handleLine;
    /** Resolve one inbound server request and write the JSON-RPC reply to stdin. */
    private answerRequest;
}
//# sourceMappingURL=client.d.ts.map
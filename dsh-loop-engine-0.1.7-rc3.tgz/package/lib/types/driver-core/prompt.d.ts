/**
 * Serialization of the durable session history into the prompt text of one
 * hosted-engine query. Every hosted driver builds its
 * per-step input from the durable session log: the transcript is the log's
 * exact projection, so a later replay of the same log derives the identical
 * prompt (Model-visible ⟺ logged bridge).
 *
 * A step whose live request is an engine slash command is the one exception to
 * the transcript framing: {@link engineSlashPrompt} sends that command line
 * verbatim, because the engines only recognize their own commands at the head
 * of the prompt. It is still derived from the log alone, so the guarantee
 * holds.
 *
 * @module dsh-loop-engine/driver-core/prompt
 */
import type { Message } from '@deepseek-ai/dsh-llm';
/** Model-facing stand-in for an image block that the hosted engines cannot consume as bytes. */
export declare const OMITTED_IMAGE_TEXT = "[image omitted: the driver does not transcribe images; read the file when a path is available]";
/**
 * The engine's own slash-command line to send as this step's entire prompt, or
 * `undefined` when the step is an ordinary conversational step.
 *
 * Every hosted engine expands a slash command only when the text handed to it
 * *starts* with `/` — Kimi's ACP adapter parses the first prompt block, Claude
 * Code's local-command dispatch and Pi's input expansion both test the leading
 * character of the message string. The serialized transcript never satisfies
 * that (it opens with `<user>`), so a forwarded `/status` reaches the model as
 * prose instead of the engine's own command surface. This helper lets a driver
 * recognize the case and send the command line verbatim, with no transcript
 * framing and no replay history: a slash command is a control line for the
 * engine, not conversation for the model.
 *
 * The live request is the last derived message, so a step whose trailing
 * message is a bare command line is a command step. A trailing skill-injection
 * message (the `/name` skill gesture the drivers materialize as its own user
 * message) displaces it and keeps the step on the transcript path.
 *
 * The returned line is a pure function of the log prefix, so the step stays
 * replayable: the same log derives the same prompt.
 * @param messages - derived history, oldest first, as returned by
 *   `Session.deriveMessages()` at step time.
 * @returns the raw command line, or `undefined` for an ordinary step.
 */
export declare function engineSlashPrompt(messages: readonly Message[]): string | undefined;
/**
 * Serialize a derived conversation history into the prompt text of one hosted
 * query. The last message is the live user request that triggered the step;
 * every earlier message is durable replay context. The output is a pure
 * function of the log prefix.
 * @param messages - derived history, oldest first, as returned by
 *   `Session.deriveMessages()` at step time.
 * @returns the prompt text to pass to the engine.
 */
export declare function serializeHistory(messages: readonly Message[]): string;
//# sourceMappingURL=prompt.d.ts.map
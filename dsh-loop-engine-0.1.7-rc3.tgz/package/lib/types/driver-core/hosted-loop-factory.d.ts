/**
 * Shared AgentFactory transaction machinery for the hosted loop engines.
 *
 * All four engines (Claude Code, Codex, Pi, Kimi Code) implement the harness's
 * single AgentFactory slot the same way: prepare a driver, scope, and one
 * memoized reverse teardown for a session; run the caller's setup under a fused
 * abort signal; publish through both registries and announce; and on resume,
 * own a session's write handle across the cold read, crash repair, and
 * re-publication. None of that touches an engine protocol — the whole
 * engine-specific surface is one call, {@link HostedLoopFactory.buildAgent}.
 *
 * This body mirrors the default in-process `agent-loop` factory; depending on
 * the `dsh-agent-loop` package is forbidden (it would claim the slot this
 * plugin exists to hand over), so the machinery is replicated here once instead
 * of four times.
 *
 * Subclasses supply:
 *   - the cordis service label, which is also the prefix of every effect label
 *     (`<label>.transactions()`, `<label>.setFactory()`, `<label>.lifecycle(id)`,
 *     `<label>.resume-load(id)`) — the lifecycle label is asserted by tests, so
 *     it must stay `<label>.lifecycle(...)`;
 *   - their own `static inject` (Codex needs no `subprocess`);
 *   - {@link HostedLoopFactory.buildAgent}.
 *
 * @module dsh-loop-engine/driver-core/hosted-loop-factory
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import type { Agent, AgentFactory, AgentHandle, AgentOptions, CreateAgentOptions, ResumeAgentOptions } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Scope } from '@deepseek-ai/dsh-scope';
/**
 * What the transaction machinery needs of a driver beyond the harness `Agent`
 * contract: a teardown entry point that also unwinds the driver's own scope.
 * The concrete engines declare these; the base only spells them out so the
 * shared body can call them generically.
 */
export interface HostedAgent extends Agent {
    /** Stop the machine with the given cause, without waiting for it to settle. */
    cancel(cause: Parameters<Agent['cancel']>[0]): void;
    /** Resolves when the machine has no work in flight. */
    whenIdle(): Promise<void>;
    /** The driver's own resource scope, unwound after the machine settles. */
    readonly scope: Scope;
}
/**
 * Concrete AgentFactory base for one hosted engine. Creation and resume follow
 * the registry factory contract and the shared publication transaction:
 * prepare, run setup, then publish through both registries, announce, and emit
 * `agent/session-start`.
 */
export declare abstract class HostedLoopFactory<TConfig, TAgent extends HostedAgent> extends Service implements AgentFactory {
    /** Validated configuration owned by the loop plugin. */
    readonly config: TConfig;
    private readonly ownership;
    /** Plain holder prevents Cordis from re-tracing the factory's dependency context through a caller shadow. */
    protected readonly runtime: {
        ctx: Context;
    };
    /** Cordis service name, also the prefix of every effect label. */
    private readonly label;
    constructor(ctx: Context, label: string, config: TConfig);
    /**
     * Construct this engine's driver for one prepared session. Called once per
     * create or resume, after the session exists and before setup runs; the
     * hook is the engine's entire protocol surface.
     */
    protected abstract buildAgent(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session): TAgent;
    /**
     * Construct the driver, scope, and one memoized reverse teardown for a new
     * agent. The teardown is registered with the factory and the owner fiber
     * BEFORE publication, so a mid-setup unload rolls everything back; `signal`
     * fuses caller cancellation with lifecycle teardown for setup awaits.
     */
    private prepare;
    /** Prepare one Agent around an acquired Session, run setup, and publish it. */
    private setupAndPublish;
    /**
     * Create an agent and session under one caller-supplied identity, owned by
     * the accessing fiber. When a persistence backend is mounted, the session's
     * durable identity is stored before publication.
     * @param ownerCtx - caller context that structurally owns the lifecycle.
     * @param options - identities, optional live parent, session seed/metadata, loop options, setup, and cancellation.
     * @returns the published handle.
     */
    createAgent(ownerCtx: Context, options: CreateAgentOptions): Promise<AgentHandle>;
    /**
     * Take a fresh session's write ownership when persistence is mounted.
     * Nothing is appended here: the constructor seed (which never re-emits
     * through `session/event`) is stored by {@link appendUnstoredSuffix} at the
     * publication commit point, so a failed or cancelled setup closes an
     * unmaterialized handle and leaves no stored residue — the same id can be
     * created again.
     * @param session - the unpublished session to store.
     * @param signal - optional cancellation forwarded to the backend create.
     * @returns the owned handle and stored cursor, or `undefined` without a backend.
     */
    private createStoredSession;
    /**
     * Durably store the session events appended since the last stored cursor.
     * Pre-publication appends (constructor seed markers, setup-window events)
     * never re-emit through `session/event`, so publication must flush them
     * through the handle before live events start routing into it.
     * @param stored - the session's owned handle and stored cursor, if any.
     * @param session - the unpublished session whose suffix is stored.
     */
    private appendUnstoredSuffix;
    /**
     * Resume an owned agent from the configured persistence service.
     * @param ownerCtx - caller context that owns load, setup, and the live lifecycle.
     * @param options - persisted identity, optional live parent, loop options, setup, and cancellation.
     * @returns the published handle.
     */
    resume(ownerCtx: Context, options: ResumeAgentOptions): Promise<AgentHandle>;
    /** Resume through an explicit persistence service. */
    private resumeWith;
}
//# sourceMappingURL=hosted-loop-factory.d.ts.map
/**
 * Live assistant-stream framing for the hosted engines.
 *
 * Harness 0.1.5 made the model stream the durable record of an assistant
 * attempt: `assistant/message` embeds its exact timed stream and may no longer
 * cite `sourceEventSeqs`, and the transient per-chunk log events the plugin
 * used to append (`assistant/chunk`) no longer exist. Live partials now travel
 * through the process-local `agent/assistant-stream` notification instead, and
 * the compact records are handed to the durable message.
 *
 * This is the driver-side equivalent of the loop's `AssistantStreamAttempt`,
 * minus the block assembly: a hosted engine keeps assembling its own
 * authoritative transcript from its own protocol, and this class only frames
 * the attempt and compacts its stream for replay fidelity.
 *
 * @module dsh-loop-engine/driver-core/assistant-stream
 */
import type { AssistantStreamFrame } from '@deepseek-ai/dsh-agent';
import { LlmAttemptId, type AssistantStreamRecord, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { SessionId, SessionSeq } from '@deepseek-ai/dsh-session';
/**
 * One model attempt on a hosted engine: ordered live frames plus the compact
 * stream the durable `assistant/message` carries.
 */
export declare class DriverAssistantStream {
    private readonly turn;
    private readonly step;
    private readonly emit;
    private accumulator;
    private index;
    private revision;
    private terminal;
    /** Attempt identity unique within this agent lifecycle. */
    readonly attemptId: LlmAttemptId;
    /**
     * @param sessionId - identity embedded only in the agent-lifecycle-local attempt id.
     * @param attempt - agent-local attempt counter.
     * @param turn - durable turn owning the request.
     * @param step - durable step owning the request.
     * @param emit - agent-scoped notification publisher.
     */
    constructor(sessionId: SessionId, attempt: number, turn: number, step: number, emit: (frame: AssistantStreamFrame) => void);
    /** Whether this attempt has already published its terminal frame. */
    get ended(): boolean;
    /** Publish the opening marker before the first delivered chunk. */
    start(): void;
    /** Snapshot one chunk once, then feed durable compaction and live publication. */
    push(chunk: StreamChunk): void;
    /** Exact compact stream for the durable assistant message. */
    get stream(): AssistantStreamRecord[];
    /**
     * Close the current record run and return it, leaving later chunks in a
     * fresh run. An engine whose protocol reports content segments (rather than
     * one stream per message) cuts at each segment boundary, so every durable
     * message embeds exactly the chunks its own content produced even though the
     * live frames keep flowing through one attempt.
     * @returns the compact records accumulated since the previous cut.
     */
    takeStream(): AssistantStreamRecord[];
    /**
     * Publish terminal settlement after the matching durable event commits.
     * @param append - synchronous durable append returning its committed seq.
     */
    settle(append: () => SessionSeq): void;
    /** Publish abandonment when no durable settlement can be committed. */
    abandon(): void;
}
//# sourceMappingURL=assistant-stream.d.ts.map
/**
 * Projection of a hosted engine's tool vocabulary onto dsh's, plus the plan
 * snapshot a hosted plan tool carries.
 *
 * The durable `tool/call` event is what the Web client's tool rows
 * (`@deepseek-ai/dsh-client-ui-chat`'s tool Definition), the produced-files row
 * and inline file links (`@deepseek-ai/dsh-client-ui-deliverables`'
 * `mutationPath`), and the trajectory view read. Those consumers recognize only
 * dsh's own tool names and argument shapes, while a hosted engine names its
 * tools differently: Claude's `Write`/`Edit`/`Read`/`Bash`, Codex's
 * `apply_patch`/`command_execution`, Kimi's title-cased `Bash`, Pi's
 * `path`-keyed arguments. This module projects a hosted call onto dsh's
 * vocabulary, and each driver feeds the projected values to BOTH writers — the
 * durable `tool/call` event and the matching `tool-call` block in the assistant
 * message that advertised it. Session V4 pairs the two by `id` and rejects a
 * log whose block and event disagree on `name` or `arguments`, so the two sides
 * must be byte-identical and both carry dsh's spelling. That spelling also lets
 * an assistant message replayed into an in-process turn name a tool dsh's
 * registry actually has (`bash`, not `Bash`).
 *
 * Only lossless projections are applied. A call whose arguments do not carry
 * the dsh fields is passed through unchanged and simply renders as a generic
 * row, so a new engine-side tool degrades instead of mis-rendering.
 *
 * Plan extraction is separate: dsh's todo panel is driven by the `todo/write`
 * session event, not by the tool row, so a driver appends that event for the
 * plan tool it recognizes.
 *
 * @module dsh-loop-engine/driver-core/hosted-tool-vocabulary
 */
/** A hosted loop engine id — the settings engine union without `in-process`. */
export type HostedEngineId = 'claude-code' | 'codex' | 'pi' | 'kimi';
/** One tool call projected into dsh's vocabulary for the durable `tool/call` event. */
export interface NormalizedHostedToolCall {
    /** dsh tool name when the projection recognizes the call, else the engine's own spelling. */
    readonly name: string;
    /** dsh-shaped arguments JSON when the projection rewrites them, else the engine's own string. */
    readonly arguments: string;
}
/** One plan entry in the shape the `todo/write` event and the todo panel consume. */
export interface HostedPlanTodo {
    /** The task line, verbatim. */
    readonly content: string;
    /** Lifecycle state, restricted to dsh's three-state union. */
    readonly status: 'pending' | 'in_progress' | 'completed';
}
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        'todo/write': {
            todos: {
                content: string;
                status: 'pending' | 'in_progress' | 'completed';
            }[];
        };
    }
}
/**
 * Project one hosted tool call onto dsh's `tool/call` vocabulary. A driver
 * calls this once per call and writes the SAME name and arguments to both the
 * assistant message's `tool-call` block and the durable `tool/call` event, so
 * Session V4's id-and-payload pairing holds.
 * @param engine - the hosted engine the call came from.
 * @param name - the engine's own tool name.
 * @param argumentsJson - the engine's arguments JSON, verbatim.
 * @returns the dsh name and (when reshaped) dsh-shaped arguments.
 */
export declare function normalizeHostedToolCall(engine: HostedEngineId, name: string, argumentsJson: string): NormalizedHostedToolCall;
/**
 * Read the whole todo list a hosted plan tool wrote, in the shape the
 * `todo/write` session event carries.
 * @param engine - the hosted engine the call came from.
 * @param name - the engine's own tool name.
 * @param argumentsJson - the engine's arguments JSON, verbatim.
 * @returns the plan entries (possibly empty) when the call is a plan write, else `undefined`.
 */
export declare function planTodosOfHostedTool(engine: HostedEngineId, name: string, argumentsJson: string): readonly HostedPlanTodo[] | undefined;
//# sourceMappingURL=hosted-tool-vocabulary.d.ts.map
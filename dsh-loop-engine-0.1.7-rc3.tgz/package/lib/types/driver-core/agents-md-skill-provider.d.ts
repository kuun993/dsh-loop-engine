/**
 * Data-driven skill provider for the hosted engines whose discovery surface is
 * "per-directory instruction files plus a skills catalog".
 *
 * Codex, Pi, and Kimi Code each expose the same two things through the dsh
 * skill-injection seam: an `agents-md` candidate merging the per-directory
 * instruction files found between the session cwd and the git root, and one
 * candidate per `SKILL.md` catalog entry. Only the *locations*, *names*, and
 * *precedence ranks* differ — never the algorithm — so those are the entire
 * configuration surface here, and each engine module supplies one
 * {@link AgentsMdProviderSpec} and a thin subclass.
 *
 * `.agents/skills` roots are deliberately absent from every engine's spec:
 * dsh's own `skill-filesystem` provider already serves them through the same
 * registry in the web profile.
 *
 * @module dsh-loop-engine/driver-core/agents-md-skill-provider
 */
import { type ContextFilePolicy } from './context-files.ts';
import type { SkillCandidate, SkillDefinition, SkillLookupOptions, SkillProvider, SkillProviderControl } from '../skills.ts';
/** A skills catalog: a per-ancestor project directory plus one user-level directory. */
export interface SkillCatalogSpec {
    /** Directory path, relative to each ancestor of the session cwd. */
    readonly project: readonly string[];
    /** Rank of project catalog entries — project instructions beat project skills. */
    readonly projectRank: number;
    /** Directory name under the user install root. */
    readonly userDir: string;
    /** Rank of user catalog entries — project files win duplicate names. */
    readonly userRank: number;
}
/** Everything that varies between the codex, pi, and kimi discovery surfaces. */
export interface AgentsMdProviderSpec {
    /** Provider identity registered against the host skills service. */
    readonly name: string;
    /** Description of the merged `agents-md` candidate. */
    readonly agentsMdDescription: string;
    /** Per-directory instruction files this engine reads, and its override. */
    readonly contextPolicy: ContextFilePolicy;
    /** The engine's user-level install root. */
    readonly userDir: () => string;
    /** Rank of the project `agents-md` candidate. */
    readonly projectRank: number;
    /** User-level instruction file inside {@link userDir}, when the engine reads one. */
    readonly userContext?: {
        readonly file: string;
        readonly rank: number;
    };
    /** Skill catalogs, when the engine has any. */
    readonly skills?: SkillCatalogSpec;
}
/**
 * Skill provider that discovers an engine's per-directory instruction files and
 * `SKILL.md` catalogs from the locations its spec names.
 */
export declare class AgentsMdSkillProvider implements SkillProvider {
    private readonly spec;
    private readonly control;
    readonly name: string;
    constructor(spec: AgentsMdProviderSpec, control: SkillProviderControl);
    list(options: SkillLookupOptions): Promise<readonly SkillCandidate[]>;
    get(candidate: SkillCandidate, _options: SkillLookupOptions): Promise<SkillDefinition | undefined>;
    /** One merged `agents-md` candidate for a ranked file set. */
    private agentsCandidate;
    /** Collect every skill in one skills directory, both nesting layouts. */
    private collectSkillsDir;
    /** One parsed skill as a ranked candidate. */
    private skillCandidate;
    /** Parse one SKILL.md file, or `undefined` when it is unreadable or invalid. */
    private tryParse;
}
//# sourceMappingURL=agents-md-skill-provider.d.ts.map
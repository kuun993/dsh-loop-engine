/**
 * Shared AgentFactory transaction machinery for the hosted loop engines.
 *
 * All four engines (Claude Code, Codex, Pi, Kimi Code) implement the harness's
 * AgentFactory contract the same way: prepare a driver, scope, and one memoized
 * reverse teardown for a session; run the caller's setup under a fused abort
 * signal; publish through both registries and announce; and on resume, own a
 * session's write handle across the cold read, crash repair, and
 * re-publication. None of that touches an engine protocol — the whole
 * engine-specific surface is one call, {@link HostedEngineRuntime.buildAgent}.
 *
 * One move has no counterpart in the harness's own factory contract and is what
 * makes an in-place engine swap possible: a LIVE session changes drivers without
 * being released. {@link HostedAgentHandle.retire} stops the outgoing machine
 * while leaving the session entered, and {@link HostedEngineRuntime.swap} builds
 * the incoming engine's machine onto that same Session. The session's store
 * entry and write handle travel across the handover in a
 * {@link SessionLifetime} — the one object that owns them.
 *
 * This body mirrors the default in-process `agent-loop` factory. It is a plain
 * class, not a Cordis plugin: the process-wide AgentFactory slot is owned by
 * the router (`router-loop.ts`, which subclasses the harness `AgentLoop`), and
 * every hosted engine is one runtime instance the router delegates to. That is
 * what lets several engines serve different sessions concurrently — the
 * harness admits exactly one factory, so the factory itself must dispatch.
 *
 * Subclasses supply:
 *   - the effect label prefix (`<label>.transactions()`,
 *     `<label>.lifecycle(id)`, `<label>.resume-load(id)`) — the lifecycle label
 *     is asserted by tests, so it must stay `<label>.lifecycle(...)`;
 *   - their own configuration resolution;
 *   - {@link HostedEngineRuntime.buildAgent}.
 *
 * @module dsh-loop-engine/driver-core/hosted-engine-runtime
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent, AgentFactory, AgentHandle, AgentOptions, AgentSetup, CreateAgentOptions, ResumeAgentOptions } from '@deepseek-ai/dsh-agent';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Scope } from '@deepseek-ai/dsh-scope';
import { SessionLifetime } from './session-lifetime.ts';
/**
 * What the transaction machinery needs of a driver beyond the harness `Agent`
 * contract: a teardown entry point that also unwinds the driver's own scope.
 * The concrete engines declare these; the base only spells them out so the
 * shared body can call them generically.
 */
export interface HostedAgent extends Agent {
    /** Stop the machine with the given cause, without waiting for it to settle. */
    cancel(cause: Parameters<Agent['cancel']>[0]): void;
    /** Resolves when the machine has no work in flight. */
    whenIdle(): Promise<void>;
    /** The driver's own resource scope, unwound after the machine settles. */
    readonly scope: Scope;
}
/**
 * The plugin's own handle for one published hosted agent: the harness contract
 * plus the two facts an in-place engine swap needs.
 *
 * A swap is two moves by two different runtimes: the outgoing engine retires its
 * machine and hands the session over, and the incoming engine builds onto that
 * session. The router is the only caller and it tracks the handle already, so
 * the harness's own `AgentHandle` — which carries neither fact — is widened
 * here rather than reaching back into a transaction that has ended.
 */
export interface HostedAgentHandle extends AgentHandle {
    /** The live session's lifetime resources, owned by this agent until it is disposed. */
    readonly lifetime: SessionLifetime;
    /**
     * Retire this machine for good while LEAVING the session alive: stop it,
     * unwind its scope, and leave the agent registry — the session's entry and
     * write handle pass to {@link SessionLifetime}'s next owner instead of being
     * released here. Only valid while this agent still owns the session: the
     * router calls it for the session's live, idle agent only.
     */
    retire(): Promise<void>;
}
/** Options for {@link HostedEngineRuntime.swap}. */
export interface SwapAgentOptions {
    /** The live session's lifetime resources, handed over by the outgoing engine. */
    readonly lifetime: SessionLifetime;
    /** Loop options for the successor; the router replays the outgoing agent's own. */
    readonly agentOptions?: AgentOptions | undefined;
    /** The composition callback the session was built with, replayed onto the successor. */
    readonly setup?: AgentSetup | undefined;
    /** The outgoing agent's runtime owner, for a child session's inherited ownership. */
    readonly parentAgent?: Agent | undefined;
}
/**
 * Concrete creation/resume machinery for one hosted engine.
 *
 * Creation and resume follow the registry factory contract and the shared
 * publication transaction: prepare, run setup, then publish through both
 * registries and await the serial `agent/created` announcement. {@link swap}
 * follows the same transaction onto a session another agent entered, which is
 * the only difference between taking a session over and owning it from birth.
 */
export declare abstract class HostedEngineRuntime<TConfig, TAgent extends HostedAgent> implements AgentFactory {
    /** Validated configuration owned by this engine instance. */
    readonly config: TConfig;
    /** Effect-label prefix; also identifies the engine in diagnostics. */
    readonly label: string;
    /** Plain holder prevents Cordis from re-tracing the factory's dependency context through a caller shadow. */
    protected readonly runtime: {
        ctx: Context;
    };
    private readonly ownership;
    /**
     * @param ctx - the owning context; its fiber's unload tears every live agent down.
     * @param label - effect-label prefix, e.g. `agentLoopKimi`.
     * @param config - already-resolved engine configuration.
     */
    constructor(ctx: Context, label: string, config: TConfig);
    /**
     * Construct this engine's driver for one prepared session. Called once per
     * create, resume, or swap, after the session exists and before setup runs; the
     * hook is the engine's entire protocol surface.
     */
    protected abstract buildAgent(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session): TAgent;
    /**
     * Construct the driver, scope, and one memoized reverse teardown for a new
     * agent. The teardown is registered with the factory and the owner fiber
     * BEFORE publication, so a mid-setup unload rolls everything back; `signal`
     * fuses caller cancellation with lifecycle teardown for setup awaits.
     *
     * `lifetime` carries the session's store entry and write handle rather than
     * this body owning them: a fresh transaction binds them when it publishes,
     * while a swap publishes a session whose entry another machine already bound
     * and whose write handle another machine already opened.
     */
    private prepare;
    /** Prepare one Agent around an acquired Session, run setup, and publish it. */
    private setupAndPublish;
    /**
     * Create an agent and session under one caller-supplied identity, owned by
     * the accessing fiber. When a persistence backend is mounted, the session's
     * durable identity is stored before publication.
     * @param ownerCtx - caller context that structurally owns the lifecycle.
     * @param options - identities, optional live parent, session seed/metadata, loop options, setup, and cancellation.
     * @returns the published handle.
     */
    createAgent(ownerCtx: Context, options: CreateAgentOptions): Promise<HostedAgentHandle>;
    /**
     * Take a fresh session's write ownership when persistence is mounted.
     * Nothing is appended here: the constructor seed (which never re-emits
     * through `session/event`) is stored by {@link appendUnstoredSuffix} at the
     * publication commit point, so a failed or cancelled setup closes an
     * unmaterialized handle and leaves no stored residue — the same id can be
     * created again.
     * @param session - the unpublished session to store.
     * @param signal - optional cancellation forwarded to the backend create.
     * @returns the owned handle and stored cursor, or `undefined` without a backend.
     */
    private createStoredSession;
    /**
     * Durably store the session events appended since the last stored cursor.
     * Pre-publication appends (constructor seed markers, setup-window events)
     * never re-emit through `session/event`, so publication must flush them
     * through the handle before live events start routing into it.
     * @param stored - the session's owned handle and stored cursor, if any.
     * @param session - the unpublished session whose suffix is stored.
     */
    private appendUnstoredSuffix;
    /**
     * Resume an owned agent from the configured persistence service.
     * @param ownerCtx - caller context that owns load, setup, and the live lifecycle.
     * @param options - persisted identity, optional live parent, loop options, setup, and cancellation.
     * @returns the published handle.
     */
    resume(ownerCtx: Context, options: ResumeAgentOptions): Promise<HostedAgentHandle>;
    /**
     * Build this engine's agent onto a LIVE session another engine's agent left,
     * taking the session's lifetime over.
     *
     * The counterpart of {@link HostedAgentHandle.retire}: together they are an
     * in-place engine swap, and the harness's own factory contract has neither.
     * Nothing is read from persistence and nothing is created in the store — the
     * successor drives the Session object that is already live and already
     * entered, so a browser half attached to that session sees no lifecycle edge
     * at all. The lifetime carries the still-open write handle, so the session
     * keeps being stored through the same channel it was already using.
     * @param ownerCtx - caller context that structurally owns the lifecycle.
     * @param options - the live session's lifetime, loop options, setup, and parent.
     * @returns the published handle, which owns the session from here on.
     */
    swap(ownerCtx: Context, options: SwapAgentOptions): Promise<HostedAgentHandle>;
    /** Resume through an explicit persistence service. */
    private resumeWith;
}
//# sourceMappingURL=hosted-engine-runtime.d.ts.map
/**
 * Per-session command and skill surface of the hosted engines.
 *
 * A hosted engine owns its session's slash-command menu and skill catalog: the
 * engine expands `/name` itself and reads its own instruction files, so the
 * plugin bridges both into the session the engine serves and nothing more.
 *
 * The registrations are made through the AGENT's own context, which is what
 * makes them session-scoped: `commands.register` and
 * `skills.registerProvider` file a definition into the layer of the calling
 * context's scope (`packages/core/scope/src/store.ts` `effect()` keys the layer
 * by `scopeOf(ctx)`), and an agent's scope key is the agent itself
 * (`createScope(loopCtx, this)` in the default loop; the hosted drivers do the
 * same). Two sessions running different engines therefore never see each
 * other's menus, and the whole surface disappears with the agent's scope — no
 * plugin-side bookkeeping, no leak across an engine switch.
 *
 * @module dsh-loop-engine/engine-surface
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { HostedEngineId } from './settings.ts';
/**
 * Bridge one hosted engine's commands and skills into the session it serves.
 *
 * Best-effort like the rest of the plugin's host-service use: a profile without
 * the commands or skills registry simply has no surface to extend. A name that
 * collides with an already-registered command in the same layer is skipped with
 * a warning rather than failing the agent: the engine expands the raw `/name`
 * line itself, so a shyer menu beats an agent that refuses to start.
 *
 * @param agent - the freshly built agent whose scope owns the registrations.
 * @param engine - the hosted engine driving that agent.
 * @param warn - sink for the skip diagnostics.
 */
export declare function registerEngineSurface(agent: Agent, engine: HostedEngineId, warn: (message: string) => void): void;
//# sourceMappingURL=engine-surface.d.ts.map
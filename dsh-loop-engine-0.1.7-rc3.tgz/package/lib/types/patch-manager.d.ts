/**
 * Managed-block editing for a profile's `cordis.patch.yml`.
 *
 * The plugin owns one contiguous block inside the user's patch file, delimited
 * by a begin/end marker pair, and rewrites only that span — everything else the
 * user wrote (other patches, their comments) survives byte for byte. The block
 * is what hands the process-wide AgentFactory slot to this plugin's router: it
 * disables the base bundle's `agent-loop` row, because the harness admits
 * exactly one AgentFactory and the router (which extends the harness loop, and
 * therefore serves `in-process` sessions too) registers itself as that one.
 *
 *   # -- dsh-loop-engine managed block --
 *   - id: agent-loop
 *     disabled: true
 *   - id: command-goal
 *     disabled: true
 *   # -- /dsh-loop-engine managed block --
 *
 * The block names no engine. Which engine a session runs is a PER-SESSION
 * decision carried by its agent preset, so it cannot live in a process-wide
 * configuration file; the block's only job is to free the slot for the router.
 * The `command-goal` row goes down with the loop: it is the host-plane copy of
 * dsh's goal command, and a goal service nothing drives has no business being
 * mounted for a profile whose loop is decided per session. The remaining
 * dsh-native commands (`/export`, `/feedback`, `/permission`) are
 * engine-agnostic session and settings controls that keep working under every
 * engine. Per-session command surfaces are the preset's business — a hosted
 * session joins an engine preset that strips `command-goal` itself, which is the
 * only place that reaches the preset-layer registration.
 *
 * Blocks written before the plugin routed per session carried the single
 * engine's id in the begin marker (`# -- dsh-loop-engine managed block:
 * claude-code --`). {@link legacyBlockEngineOf} reads that form so an upgrade
 * can carry the pinned engine into the settings seed before the block is
 * rewritten to the engine-agnostic form; a legacy block is otherwise treated as
 * a present block by {@link hasManagedBlock}.
 *
 * All functions here are pure string transforms — file I/O and durability live
 * in the plugin's apply.
 *
 * @module dsh-loop-engine/patch-manager
 */
import type { LoopEngineId } from './settings.ts';
/** Begin marker of the plugin-managed span inside a profile patch file. */
export declare const MANAGED_BLOCK_BEGIN = "# -- dsh-loop-engine managed block --";
/**
 * Begin-marker prefix of the pre-routing block form, which named the one engine
 * the profile was pinned to.
 */
export declare const LEGACY_MANAGED_BLOCK_BEGIN = "# -- dsh-loop-engine managed block: ";
/** End marker of the plugin-managed span inside a profile patch file. */
export declare const MANAGED_BLOCK_END = "# -- /dsh-loop-engine managed block --";
/** The loader patch that frees the single AgentFactory slot for the router. */
export declare function renderManagedBlock(): string;
/**
 * Whether a patch-file text contains the LEGACY managed block span, which
 * named the single engine the profile used to be pinned to.
 */
export declare function hasLegacyManagedBlock(text: string): boolean;
/**
 * Whether a patch-file text contains the managed block span, in either the
 * current or the legacy form.
 */
export declare function hasManagedBlock(text: string): boolean;
/**
 * The engine a LEGACY managed block pinned the profile to, when the block has
 * that form and names an engine this build knows. `undefined` covers the
 * current engine-agnostic block, no block at all, and a legacy block naming an
 * engine this build does not recognize.
 */
export declare function legacyBlockEngineOf(text: string): LoopEngineId | undefined;
/**
 * Produce the next patch-file text carrying the managed block, preserving every
 * byte outside the managed span. Appends the span when absent and replaces it
 * when present — including a legacy span, which is rewritten to the current
 * form. The managed block is a root-level collection, so a leftover seed `[]`
 * is dropped with it, leaving the file a single valid top-level array the
 * harness can boot: the block's own `- id: agent-loop` is a column-0 entry, so
 * a file carrying it never needs a re-seed.
 * @param text - current patch-file text.
 * @returns the rewritten patch-file text.
 */
export declare function applyManagedBlock(text: string): string;
//# sourceMappingURL=patch-manager.d.ts.map
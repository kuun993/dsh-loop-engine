/**
 * Maps `kimi acp` `session/update` events to dsh session-log projections.
 *
 * Kimi streams incremental assistant text (`agent_message_chunk`), incremental
 * thinking (`agent_thought_chunk`), a tool-call announcement (`tool_call`) and its
 * progress/result updates (`tool_call_update`). Assistant text and thinking are
 * Deltas; a tool update's content is a whole Snapshot that replaces the previous
 * one. A tool call's identity arrives on the announcement but its input
 * (`rawInput`) does not — only a later update carries it. This module is pure: it
 * classifies an update, extracts chunk deltas, and projects the tool-call
 * identity/input/content/result so the agent can fold them into the durable log.
 * Content blocks use the observed kimi
 * `{ type: 'content', content: { type: 'text', text } }` nesting; unknown block
 * types are ignored.
 *
 * @module dsh-loop-engine/engine-kimi/acp/mapping
 */
import type { ToolResultMessage } from '@deepseek-ai/dsh-llm';
import type { AcpContentBlock, AcpToolCallExt, AcpToolCallStreamExt, AcpUpdate } from './types.ts';
/** Whether the update is an incremental assistant text chunk. */
export declare function isTextChunk(update: AcpUpdate): update is AcpUpdate & {
    readonly sessionUpdate: 'agent_message_chunk';
    readonly content: AcpContentBlock;
};
/** Whether the update is an incremental thinking chunk. */
export declare function isThoughtChunk(update: AcpUpdate): update is AcpUpdate & {
    readonly sessionUpdate: 'agent_thought_chunk';
    readonly content: AcpContentBlock;
};
/** Whether the update announces a tool call. */
export declare function isToolCall(update: AcpUpdate): update is AcpToolCallExt;
/** Whether the update streams a tool call's progress/result. */
export declare function isToolCallUpdate(update: AcpUpdate): update is AcpToolCallStreamExt;
/** The delta text of a text/thinking chunk. */
export declare function chunkDelta(update: AcpUpdate): string;
/** The raw tool-call id (+ content index) as the wire carries it. */
export declare function toolCallIdOf(update: AcpUpdate): string;
/** The tool display name (`title`). */
export declare function toolCallName(update: AcpUpdate): string;
/**
 * The tool call's real input as the JSON `arguments` string the durable
 * `tool/call` carries, when the frame supplies it.
 *
 * The `tool_call` announcement never carries `rawInput`; a later
 * `tool_call_update` does (measured against kimi 0.28.x: the execution-start
 * frame, `status: 'in_progress'`). A call's arguments are therefore unknowable
 * at announce time, and the driver logs the call only once an update supplies
 * them — or when the call settles, whichever comes first.
 * @param update - one tool-call announcement or update.
 * @returns the arguments string, or `undefined` when the frame omits the field.
 */
export declare function toolRawInput(update: AcpToolCallExt | AcpToolCallStreamExt): string | undefined;
/** Whether a tool stream status is settled (no longer streaming). */
export declare function isToolSettledStatus(status: string): boolean;
/** Whether a tool stream status denotes a failure. */
export declare function isToolErrorStatus(status: string): boolean;
/**
 * The tool call's content as ONE update carries it: the joined text of its
 * observed `{ type: 'content', content: { type: 'text', text } }` blocks.
 *
 * Kimi re-sends the call's whole content on every `tool_call_update` rather than
 * streaming deltas (measured against 0.28.1: the string grows from the tool
 * input's rendering to the final output), so this is a *snapshot* — callers
 * replace with it, never append. `undefined` means the update carried no
 * content field at all (nothing to replace), which is distinct from a present
 * but empty one.
 * @param update - one tool-call announcement or update.
 * @returns the content snapshot, or `undefined` when the field is absent.
 */
export declare function toolContentText(update: AcpToolCallExt | AcpToolCallStreamExt): string | undefined;
/** Project a completed tool call to a durable tool/result message. */
export declare function toolResult(callId: string, text: string, isError: boolean): ToolResultMessage;
//# sourceMappingURL=mapping.d.ts.map
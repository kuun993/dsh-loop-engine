/**
 * JSON-RPC client for the `kimi acp` subprocess (Agent Client Protocol over
 * stdio).
 *
 * The driver hands the client a process handle carrying its stdin/stdout/stderr
 * (projected from the dsh subprocess seam). The client frames JSON-RPC 2.0
 * records on a bare `\n` (via a byte decoder, tolerating a trailing `\r`),
 * correlates request responses by `id`, dispatches every `session/update`
 * notification to a buffered event stream, and answers the reverse-RPC
 * `session/request_permission` requests the agent publishes. The child is
 * long-lived (one per factory) and stepped over via `newSession` + `prompt`.
 *
 * @module dsh-loop-engine/engine-kimi/acp/client
 */
import type { KimiProcess, KimiSpawnCapability, KimiSpawnSpec } from '../process.ts';
import { type AcpFrame, type AcpPermissionOption, type AcpPermissionResponse, type AcpUpdate } from './types.ts';
/** How the client answers one `session/request_permission`. */
export type AcpPermissionHandler = (request: AcpFrame) => boolean | Promise<boolean>;
/**
 * The answerable options of one `session/request_permission` frame. The wire is
 * untrusted, so entries without a usable `optionId` are dropped rather than
 * echoed back.
 * @param frame - the reverse-RPC request frame.
 * @returns the options the client may answer with.
 */
export declare function permissionOptionsOf(frame: AcpFrame): readonly AcpPermissionOption[];
/**
 * Encode one approval decision as the ACP `RequestPermissionResponse` the agent
 * correlates against the options it advertised. The agent reads a terminal
 * *option*, never a boolean: an outcome it cannot resolve (or a response that
 * fails to parse at all) is reported to the model as a user rejection, so a
 * decision that no single option expresses becomes `cancelled` — the honest
 * "this client has no answer". Kimi re-uses this RPC for its question and
 * plan-review bridges, which offer one `allow_once` option per choice; picking
 * one of those would answer a question no human was asked, so any ambiguous
 * set (zero or several `allow_once`/`reject_once` candidates) cancels instead.
 * `allow_once` is preferred over `allow_always` because the decision is re-read
 * from the session knobs on every request: letting the agent cache a session
 * grant would outlive a mid-session switch back to `ask`.
 * @param approved - whether the driver approves the request.
 * @param options - the options the agent advertised for this request.
 * @returns the result payload to send back.
 */
export declare function permissionResponse(approved: boolean, options: readonly AcpPermissionOption[]): AcpPermissionResponse;
/** Callback receiving every non-response event line. */
export type AcpUpdateHandler = (update: AcpUpdate) => void;
/**
 * ACP client over one `kimi acp` child. Created once per driver scope and reused
 * across steps, matching the Pi RPC client's lifecycle.
 */
export declare class AcpClient {
    private readonly process;
    private readonly pending;
    private readonly updateBuffer;
    private updateWake;
    private updateHandler;
    private permissionHandler;
    private sealed;
    private nextId;
    private readonly decoder;
    private buffer;
    /** Whether this client was sealed or its process exited. */
    get closed(): boolean;
    /** Mount a client over an already-spawned `kimi acp` process. */
    constructor(process: KimiProcess);
    /**
     * Create a client, spawning the `kimi acp` child through the supplied
     * capability (or the default node spawn when none is given).
     * @param spec - the `kimi acp` argv/cwd/env the child should run with.
     * @param spawn - optional process-spawn capability (the subprocess seam).
     * @returns the connected client.
     */
    static create(spec: KimiSpawnSpec, spawn?: KimiSpawnCapability): AcpClient;
    /** Register the event dispatch handler. */
    onUpdate(handler: AcpUpdateHandler): void;
    /** Register the permission-approval handler (reverse-RPC answers). */
    onPermission(handler: AcpPermissionHandler): void;
    /** Send one request and await the correlated response. */
    request(method: string, params: unknown): Promise<unknown>;
    /** Send a notification (no correlated response awaited). */
    notify(method: string, params: unknown): void;
    /** Open the protocol handshake. */
    initialize(): Promise<unknown>;
    /** Start a fresh ACP session and resolve to its session id. */
    newSession(cwd: string): Promise<string>;
    /**
     * Select the model for one ACP session. The agent answers with an error frame
     * when it cannot serve the id, and {@link request} rejects on that frame — so
     * an engine that refuses the model fails the step loud rather than silently
     * running its own default.
     * @param sessionId - the ACP session the model applies to.
     * @param modelId - the model id to select.
     * @returns the agent's response to `session/set_model`.
     */
    setModel(sessionId: string, modelId: string): Promise<unknown>;
    /** Prompt the agent in a session and resolve when the turn completes. */
    prompt(sessionId: string, text: string): Promise<unknown>;
    /** Cancel the active turn in a session (fire-and-forget). */
    cancel(sessionId: string): void;
    /**
     * Answer a pending `session/request_permission`.
     * @param id - the reverse-RPC request id.
     * @param response - the ACP outcome to answer with.
     */
    respondPermission(id: number, response: AcpPermissionResponse): void;
    /** Consume every buffered update as an async generator. */
    updates(): AsyncGenerator<AcpUpdate, void, void>;
    /** Seal the client and request child termination. */
    dispose(): void;
    private feed;
    /** Dispatch one parsed line: a response, an update notification, or a reverse-RPC request. */
    private dispatch;
    private settle;
    private handlePermission;
}
//# sourceMappingURL=client.d.ts.map
/**
 * Kimi Code loop Agent: drives one session through turn and step boundaries over
 * a persistent `kimi acp` child (Agent Client Protocol over stdio), speaking one
 * stateless `session/new` + `session/prompt` per dsh step. The dsh session log is
 * the sole source of model context and the prompt is a pure serialization of the
 * durable history, so the transcript stays Model-visible ⟺ logged. Kimi owns its
 * system prompt and tools natively; the ACP child is spawned through the dsh
 * subprocess seam (the only available privilege boundary) and tool approvals are
 * answered from the session's dsh approval knobs.
 *
 * @module dsh-loop-engine/engine-kimi/agent
 */
import type { Agent, AgentCancelCause, AgentOptions, AgentStatus, CancelOptions, InboxTarget } from '@deepseek-ai/dsh-agent';
import type { Scope } from '@deepseek-ai/dsh-scope';
import type { Session, SessionId, UserMessage } from '@deepseek-ai/dsh-session';
import type { Context } from '@deepseek-ai/cordis';
import type { ResolvedConfig } from './types.ts';
import { DriverInbox } from '../driver-core/inbox.ts';
import type { KimiSpawnCapability } from './process.ts';
/**
 * Provider route label this driver logs into request/header snapshots and
 * message provenance — the ONE route every hosted engine shares
 * ({@link HOSTED_ROUTE_LABEL}), so all four engines select `external/default`
 * and the model menu carries a single group instead of one per engine.
 */
export declare const PROVIDER = "external";
/** Drives one session through turn and step boundaries on Kimi Code. */
export declare class KimiAgent implements Agent {
    private loopCtx;
    readonly id: SessionId;
    readonly options: AgentOptions;
    readonly session: Session;
    private readonly config;
    private readonly spawn;
    private readonly bin;
    readonly inbox: DriverInbox;
    private phase;
    private activityDone;
    /** The agent-scoped registration boundary; the lifecycle owner unwinds it after the driver exits. */
    readonly scope: Scope;
    readonly ctx: Context;
    /** Fused dispatcher, built once in the constructor so hot-path dispatches never allocate. */
    private readonly dispatch;
    /** Whether this loop instance has appended its initial/resume request anchor. */
    private requestHeaderLogged;
    /** Agent-lifecycle-local counter naming each streamed attempt. */
    private streamAttempts;
    /** Lazily created ACP client, reused across steps and released on scope teardown. */
    private acp;
    /** The spawn spec the cached client was built from; a change forces a respawn. */
    private lastSpec;
    /**
     * The environment the last handover produced, memoized by its own content so
     * an unchanged endpoint reuses ONE object: `specsEqual` compares environments
     * by reference, and a fresh object per step would otherwise respawn the child
     * every step.
     */
    private handoverEnvCache;
    constructor(loopCtx: Context, id: SessionId, options: AgentOptions, session: Session, config: ResolvedConfig, spawn: KimiSpawnCapability, bin: string);
    get status(): AgentStatus;
    /** Commit a phase and publish its externally visible status transition. */
    private setPhase;
    send(message: UserMessage, target: InboxTarget, wakeup: boolean): void;
    /**
     * Queue a message for the next turn and wake the driver.
     * @param input - the user message to deliver.
     */
    followup(input: UserMessage): void;
    /**
     * Queue a message for the running step and wake the driver.
     * @param input - the user message to deliver.
     */
    steer(input: UserMessage): void;
    /**
     * Queue a message for the running step without waking the driver.
     * @param input - the user message to deliver.
     */
    inject(input: UserMessage): void;
    cancel(cause: AgentCancelCause, options?: CancelOptions): void;
    /**
     * Run a maintenance job while the agent is idle.
     * @param job - the maintenance operation, receiving the phase abort signal.
     * @returns the maintenance result.
     */
    runMaintenance<T>(job: (signal: AbortSignal) => Promise<T>): Promise<T>;
    /**
     * Start one driver, or latch its wake behind maintenance or an aborted
     * activity. A wake sent while idle always opens its turn boundary, even
     * when its message was cleared; only a latched replay is suppressed when
     * the queue no longer holds the wake.
     * @param wakeAfterAbort - the {@link send} classification, captured before
     *   the inbox insertion so a reentrant cancel cannot reclassify it.
     */
    private wakeDriver;
    whenIdle(): Promise<void>;
    /** Report one failure at its live boundary, then preserve it for driver containment. */
    private throwError;
    private kick;
    private preStep;
    /**
     * Scan the step's user messages for `/name` skill gestures, load each
     * matching skill, and inject the rendered skill content into the message
     * batch. This mirrors what dsh-tool-skill does for the in-process engine.
     * @param messages - the current step's message batch.
     * @param signal - cancellation signal (aborted loads are silently dropped).
     * @returns the original batch when no skill was invoked, or an extended
     *   batch with injected skill-content messages appended.
     */
    private injectSkills;
    /** Open one turn before claiming its first proposed step. */
    private turn;
    /** Model label recorded in the request header for one lifecycle. */
    private modelLabel;
    /** Append the request header snapshot once per loop instance. */
    private assertRequestHeader;
    /** Whether two spawn specs describe the same `kimi acp` child. */
    private specsEqual;
    /** Return the cached ACP client, respawning when the spec or process changed. */
    private acpClient;
    /** Build the `kimi acp` argv/cwd/env for the persistent child. */
    private spawnSpec;
    /**
     * The child environment for one handover, memoized by content so an unchanged
     * endpoint yields the SAME object across steps (see {@link handoverEnvCache}).
     */
    private handoverEnv;
    /** Run one `kimi acp` step for the current session history and map the streamed updates. */
    private step;
    /** Per-step accumulation state for streamed assistant blocks and tool calls. */
    private blocks;
    /**
     * Announced calls still waiting for the update that carries their input,
     * keyed by call id, holding the latest content snapshot seen meanwhile (a
     * frame can report output before it reports input). `toolContent` holds the
     * calls already logged, so a call is in exactly one of the two.
     */
    private pendingCalls;
    /** Whether the current step published any assistant message at all. */
    private producedOutput;
    /**
     * Tool results logged into the currently open step. A result means the
     * segment that requested the call is finished, so the next assistant content
     * opens the next step (see {@link beginSegment}).
     */
    private stepSettledTools;
    /**
     * Tool calls the current segment has already received input for, awaiting the
     * segment's single assistant message. A model turn that announces several
     * calls before any result must land them all in ONE message — the chat node
     * keys by `${turn}:${step}` and replaces blocks on every message, so a second
     * message would overwrite the first one's reasoning/text (and tool-call head).
     * The list is flushed once, when the segment closes (its first settled result).
     */
    private segmentCalls;
    /** Latest content snapshot per logged tool call (see {@link applyUpdate}). */
    private toolContent;
    /** The live attempt framing the assistant message being assembled right now. */
    private live;
    private blockRef;
    private ensureBlock;
    /**
     * Rotate to the next step when the segment that ran a tool has finished, so
     * each assistant segment lands in its own step.
     *
     * Called as new assistant content begins. A step holding a settled tool
     * result means the previous segment is complete, and the content about to be
     * applied belongs to the next one. Rotating here (rather than when a call is
     * announced) keeps calls that were announced before any result — one model
     * turn — in a single step.
     */
    private beginSegment;
    /** Apply one streamed update to the open step's blocks and stream. */
    private applyUpdate;
    /** The live attempt framing the current segment, opened on its first chunk. */
    private currentStream;
    /**
     * Flush the open segment's single assistant message and every `tool/call` it
     * accumulated, in the load-bearing order assistant/message → tool/call. One
     * segment produces exactly ONE message even when the model announced several
     * calls before any result, because the chat view keys an assistant node by
     * `${turn}:${step}` and replaces its blocks on every message — a second
     * message in the same step would overwrite the first one's reasoning/text and
     * leave only the last bare tool-call head visible.
     * @param phase - the open step the segment belongs to.
     */
    private flushSegment;
    /**
     * Flush the accumulated assistant blocks into one durable assistant/message
     * carrying the exact stream the attempt published live, optionally closing it
     * with the tool-call block(s) that ended the segment.
     *
     * Every flush settles its own attempt (and so its own live `end` frame): a
     * step emits one message per assistant segment, and the client pairs a durable
     * message with the attempt whose `end` cites it, so two messages may not share
     * one attempt.
     * @param phase - the open step the message belongs to.
     * @param toolCalls - the calls that closed this segment, rendered as trailing
     *   `tool-call` content blocks. A segment with no blocks of its own — a step
     *   whose only activity was a tool call — still emits this message, so its
     *   `tool/call` and `tool/result` events have a parent to pair with.
     */
    private flushAssistant;
}
//# sourceMappingURL=agent.d.ts.map
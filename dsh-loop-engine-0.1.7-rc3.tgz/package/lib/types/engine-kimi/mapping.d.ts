/**
 * Mapping from Kimi Code `--output-format stream-json` records to dsh
 * session-log events. Kimi emits one JSON object per stdout line, discriminated
 * by a `role` field (verified against the 0.28.1 CLI):
 *   - `{ "role": "assistant", "content": "<text>" }`
 *   - `{ "role": "assistant", "tool_calls": [{ "type": "function",
 *       "id": "call_…", "function": { "name": "Bash", "arguments": "<json>" } }] }`
 *   - `{ "role": "tool", "tool_call_id": "call_…", "content": "<text>" }`
 *   - `{ "role": "meta", "type": "session.resume_hint", … }` (discarded)
 * Thinking and tool progress go to stderr, never the JSONL, so this module has no
 * usage or reasoning projection. The module is pure: it parses a raw stdout
 * buffer and returns plain record projections the agent folds into the log.
 *
 * @module dsh-loop-engine/engine-kimi/mapping
 */
import type { ToolResultMessage } from '@deepseek-ai/dsh-llm';
/** One normalized Kimi tool-call record. */
export interface KimiToolCall {
    /** The tool invocation id (`call_…`), correlated with the later `tool` record. */
    readonly id: string;
    /** The tool name. */
    readonly name: string;
    /** The raw arguments JSON string, passed verbatim. */
    readonly arguments: string;
}
/** One parsed Kimi stream-json record (partial, tolerant of unknown fields). */
export interface KimiRecord {
    readonly role?: unknown;
    readonly type?: unknown;
    readonly content?: unknown;
    readonly tool_calls?: unknown;
    readonly tool_call_id?: unknown;
    readonly is_error?: unknown;
    readonly isError?: unknown;
    readonly error?: unknown;
}
/** Record role discriminant used by the step loop. */
export type KimiRecordRole = 'assistant' | 'tool' | 'meta' | 'unknown';
/**
 * Parse a `kimi --output-format stream-json` stdout buffer into records.
 * Lines are bare-`\n` delimited; blank lines and non-JSON lines are dropped.
 * @param stdout - the child's full stdout text.
 * @returns the parsed records, in order.
 */
export declare function parseKimiRecords(stdout: string): KimiRecord[];
/** Classify one record's role. */
export declare function roleOf(record: KimiRecord): KimiRecordRole;
/**
 * The joined text of one record's `content` field. Handles both the string
 * form (`"content": "<text>"`) and an array form (`[{ "type": "text", "text": … }]`)
 * defensively; any other shape renders empty.
 * @param record - the parsed record.
 * @returns the joined body text.
 */
export declare function recordContentText(record: KimiRecord): string;
/**
 * Normalize an assistant record's `tool_calls` array. Each entry keeps its id,
 * name, and a verbatim argument string (the wire already serializes arguments
 * as JSON text; absent args render `{}`).
 * @param record - the parsed assistant record.
 * @returns the normalized tool calls, in order.
 */
export declare function assistantToolCalls(record: KimiRecord): readonly KimiToolCall[];
/**
 * Surface a `tool` record as a durable tool-result message, or `undefined` when
 * the record is not a correlatable tool result (missing `role: tool` or no id).
 * @param record - the parsed record.
 * @returns the dsh tool-result message, or `undefined`.
 */
export declare function toolResultMessage(record: KimiRecord): ToolResultMessage | undefined;
//# sourceMappingURL=mapping.d.ts.map